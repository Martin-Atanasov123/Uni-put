import { Route, Routes, useLocation } from "react-router";
import { Suspense, lazy } from "react";
import { LazyMotion, domAnimation } from "motion/react";

import { AuthProvider } from "@/hooks/AuthContext";
import ProtectedRoute from "@/routes/ProtectedRoute";

import Header from "@/components/common/Header";
import Footer from "@/components/common/Footer";
import GlobalErrorBoundary from "@/components/common/GlobalErrorBoundary";

import AdminRoute from "@/routes/AdminRoute";
import ScrollToTop from "@/components/common/ScrollToTop";
import PremiumRouteFrame from "@/components/common/PremiumRouteFrame";

const Home            = lazy(() => import("@/components/common/Home"));
const NotFound        = lazy(() => import("@/components/common/NotFound"));
const Login           = lazy(() => import("@/components/Auth/Login"));
const Register        = lazy(() => import("@/components/Auth/Register"));
const ForgotPassword  = lazy(() => import("@/components/Auth/ForgotPassword"));
const UpdatePassword  = lazy(() => import("@/components/Auth/UpdatePassword"));
const About           = lazy(() => import("@/components/common/About"));
const UniversitiesPage= lazy(() => import("@/components/Universities/Universities"));
const UniversityPage  = lazy(() => import("@/components/Universities/UniversityPage"));
const SpecialtyPage   = lazy(() => import("@/components/Universities/SpecialtyPage"));
const SpecialtiesIndex= lazy(() => import("@/components/Universities/SpecialtiesIndex"));
const CareerAdvisor   = lazy(() => import("@/components/CareerAdvisor/CareerAdvisor"));
const TestCareer      = lazy(() => import("@/components/CareerAdvisor/TestCareer"));
const DziStrategist   = lazy(() => import("@/components/DziStrategist/DziStrategist"));
const GymnasiaPage    = lazy(() => import("@/components/Gymnasia/Gymnasia"));
const Dormitories     = lazy(() => import("@/components/Dormitories/Dormitories"));
const CalendarPage    = lazy(() => import("@/components/Calendar/Calendar"));
const FavoritesPage   = lazy(() => import("@/components/Favorites/Favorites"));
const CalculatorPage  = lazy(() => import("@/components/Calculator/Calculator"));
const Profile         = lazy(() => import("@/components/Auth/Profile"));
const AdminDashboard  = lazy(() => import("@/components/admin/AdminDashboard"));
const AdminReports    = lazy(() => import("@/components/admin/AdminReports"));
const TermsOfService  = lazy(() => import("@/components/common/TermsOfService"));
const PrivacyPolicy   = lazy(() => import("@/components/common/PrivacyPolicy"));
const MyGradesPage    = lazy(() => import("@/components/MyGrades/MyGrades"));
const ReminderAction  = lazy(() => import("@/components/common/ReminderAction"));

function PageWrap({ children }) {
    return (
        <PremiumRouteFrame>
            {children}
        </PremiumRouteFrame>
    );
}

function PageLoader() {
    return (
        <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center',
                      justifyContent: 'center', background: 'var(--brand-bg)' }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%',
                          border: '3px solid var(--brand-border)',
                          borderTopColor: 'var(--brand-cyan)',
                          animation: 'spin 0.7s linear infinite' }} />
        </div>
    );
}

function App() {
    const location = useLocation();
    return (
        <GlobalErrorBoundary>
            <LazyMotion features={domAnimation}>
                <AuthProvider>
                    <ScrollToTop />
                    <Header />
                    <main id="main" role="main">
                        <Suspense fallback={<PageLoader />}>
                            {/* Без AnimatePresence mode="wait": exit-анимацията чакаше
                                старата страница да излезе преди новата да се монтира.
                                При бързо превключване + lazy chunks (Suspense) това
                                губеше навигации — URL се сменя, страницата не.
                                key-ът остава: нов mount (и entry анимация) на всеки път. */}
                            <Routes location={location} key={location.pathname}>
                                    {/* Публични маршрути */}
                                    <Route path="*" element={<PageWrap><NotFound /></PageWrap>} />
                                    <Route path="/" element={<PageWrap><Home /></PageWrap>} />
                                    <Route path="/login" element={<PageWrap><Login /></PageWrap>} />
                                    <Route path="/register" element={<PageWrap><Register /></PageWrap>} />
                                    <Route path="/forgot-password" element={<PageWrap><ForgotPassword /></PageWrap>} />
                                    <Route path="/update-password" element={<PageWrap><UpdatePassword /></PageWrap>} />
                                    <Route path="/about" element={<PageWrap><About /></PageWrap>} />
                                    <Route path="/terms" element={<PageWrap><TermsOfService /></PageWrap>} />
                                    <Route path="/privacy" element={<PageWrap><PrivacyPolicy /></PageWrap>} />
                                    <Route path="/reminders/confirm" element={<PageWrap><ReminderAction /></PageWrap>} />
                                    <Route path="/reminders/unsubscribe" element={<PageWrap><ReminderAction /></PageWrap>} />
                                    <Route path="/universities" element={<PageWrap><UniversitiesPage /></PageWrap>} />
                                    <Route path="/universities/:uniSlug" element={
                                        <PageWrap><GlobalErrorBoundary><UniversityPage /></GlobalErrorBoundary></PageWrap>
                                    } />
                                    <Route path="/specialnosti" element={
                                        <PageWrap><GlobalErrorBoundary><SpecialtiesIndex /></GlobalErrorBoundary></PageWrap>
                                    } />
                                    <Route path="/specialnosti/:specSlug" element={
                                        <PageWrap><GlobalErrorBoundary><SpecialtyPage /></GlobalErrorBoundary></PageWrap>
                                    } />
                                    <Route path="/career-advisor" element={
                                        <PageWrap><GlobalErrorBoundary><CareerAdvisor /></GlobalErrorBoundary></PageWrap>
                                    } />
                                    <Route path="/test-career" element={
                                        <PageWrap><GlobalErrorBoundary><TestCareer /></GlobalErrorBoundary></PageWrap>
                                    } />
                                    <Route path="/dzi-strateg" element={
                                        <PageWrap><GlobalErrorBoundary><DziStrategist /></GlobalErrorBoundary></PageWrap>
                                    } />
                                    <Route path="/priem-7-klas" element={
                                        <PageWrap><GlobalErrorBoundary><GymnasiaPage /></GlobalErrorBoundary></PageWrap>
                                    } />
                                    <Route path="/dormitories" element={<PageWrap><Dormitories /></PageWrap>} />
                                    <Route path="/calendar" element={
                                        <PageWrap><GlobalErrorBoundary><CalendarPage /></GlobalErrorBoundary></PageWrap>
                                    } />
                                    {/* Любими: публично — работят и без акаунт (localStorage),
                                        синхронизират се при вход. CLAUDE.md: без login wall пред стойност. */}
                                    <Route path="/favorites" element={
                                        <PageWrap><FavoritesPage /></PageWrap>
                                    } />
                                    {/* Калкулаторът е публичен — CLAUDE.md: "Never put a login wall between a user and their first calculator result" */}
                                    <Route path="/calculator" element={
                                        <PageWrap><GlobalErrorBoundary><CalculatorPage /></GlobalErrorBoundary></PageWrap>
                                    } />
                                    <Route path="/my-grades" element={
                                        <PageWrap><MyGradesPage /></PageWrap>
                                    } />
                                    <Route path="/profile" element={
                                        <PageWrap><ProtectedRoute><Profile /></ProtectedRoute></PageWrap>
                                    } />
                                    {/* Админ маршрути (изискват админ роля) */}
                                    <Route path="/admin" element={
                                        <PageWrap>
                                            <AdminRoute>
                                                <GlobalErrorBoundary><AdminDashboard /></GlobalErrorBoundary>
                                            </AdminRoute>
                                        </PageWrap>
                                    } />
                                    <Route path="/admin/reports" element={
                                        <PageWrap>
                                            <AdminRoute>
                                                <GlobalErrorBoundary><AdminReports /></GlobalErrorBoundary>
                                            </AdminRoute>
                                        </PageWrap>
                                    } />
                                </Routes>
                        </Suspense>
                    </main>
                    <Footer />
                </AuthProvider>
            </LazyMotion>
        </GlobalErrorBoundary>
    );
}

export default App;
