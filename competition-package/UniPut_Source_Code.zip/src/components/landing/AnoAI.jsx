/**
 * ShaderBackground — Plasma grid WebGL background
 * Source: https://21st.dev/r/minhxthanh/animated-shader-background
 * Adapted: container-relative sizing, ResizeObserver, proper RAF cleanup.
 * Uses raw WebGL (no Three.js dependency).
 */

// ── Shaders (outside component — never recreated) ────────────────────────────

const VS_SOURCE = `
  attribute vec4 aVertexPosition;
  void main() {
    gl_Position = aVertexPosition;
  }
`;

const FS_SOURCE = `
  precision highp float;
  uniform vec2 iResolution;
  uniform float iTime;
  uniform vec3 uBackgroundStart;
  uniform vec3 uBackgroundEnd;
  uniform vec3 uLineStart;
  uniform vec3 uLineEnd;
  uniform float uEdgeFade;

  const float overallSpeed       = 0.2;
  const float gridSmoothWidth    = 0.015;
  const float axisWidth          = 0.05;
  const float majorLineWidth     = 0.025;
  const float minorLineWidth     = 0.0125;
  const float majorLineFrequency = 5.0;
  const float minorLineFrequency = 1.0;
  const vec4  gridColor          = vec4(0.5);
  const float scale              = 5.0;
  // line color computed per-line in main() loop
  const float minLineWidth       = 0.01;
  const float maxLineWidth       = 0.2;
  const float lineSpeed          = 0.5  * overallSpeed;
  const float lineAmplitude      = 1.0;
  const float lineFrequency      = 0.2;
  const float warpSpeed          = 0.1  * overallSpeed;
  const float warpFrequency      = 0.5;
  const float warpAmplitude      = 1.0;
  const float offsetFrequency    = 0.5;
  const float offsetSpeed        = 0.27 * overallSpeed;
  const float minOffsetSpread    = 0.6;
  const float maxOffsetSpread    = 2.0;
  const int   linesPerGroup      = 14;

  #define drawCircle(pos, radius, coord) smoothstep(radius + gridSmoothWidth, radius, length(coord - (pos)))
  #define drawSmoothLine(pos, halfWidth, t) smoothstep(halfWidth, 0.0, abs(pos - (t)))
  #define drawCrispLine(pos, halfWidth, t) smoothstep(halfWidth + gridSmoothWidth, halfWidth, abs(pos - (t)))
  #define drawPeriodicLine(freq, width, t) drawCrispLine(freq / 2.0, width, abs(mod(t, freq) - (freq) / 2.0))

  float drawGridLines(float axis) {
    return drawCrispLine(0.0, axisWidth, axis)
         + drawPeriodicLine(majorLineFrequency, majorLineWidth, axis)
         + drawPeriodicLine(minorLineFrequency, minorLineWidth, axis);
  }

  float drawGrid(vec2 space) {
    return min(1.0, drawGridLines(space.x) + drawGridLines(space.y));
  }

  float random(float t) {
    return (cos(t) + cos(t * 1.3 + 1.3) + cos(t * 1.4 + 1.4)) / 3.0;
  }

  float getPlasmaY(float x, float horizontalFade, float offset) {
    return random(x * lineFrequency + iTime * lineSpeed) * horizontalFade * lineAmplitude + offset;
  }

  void main() {
    vec2 fragCoord = gl_FragCoord.xy;
    vec4 fragColor;
    vec2 uv    = fragCoord.xy / iResolution.xy;
    vec2 space = (fragCoord - iResolution.xy / 2.0) / iResolution.x * 2.0 * scale;

    float horizontalFade = 1.0 - (cos(uv.x * 6.28) * 0.5 + 0.5);
    float verticalFade   = 1.0 - (cos(uv.y * 6.28) * 0.5 + 0.5);

    space.y += random(space.x * warpFrequency + iTime * warpSpeed) * warpAmplitude * (0.5 + horizontalFade);
    space.x += random(space.y * warpFrequency + iTime * warpSpeed + 2.0) * warpAmplitude * horizontalFade;

    vec4 lines    = vec4(0.0);
    float lineMask = 0.0;
    vec4 bgColor1 = vec4(uBackgroundStart, 1.0);
    vec4 bgColor2 = vec4(uBackgroundEnd, 1.0);
    vec4 brandCyan   = vec4(uLineStart, 1.0);
    vec4 brandViolet = vec4(uLineEnd, 1.0);

    for (int l = 0; l < linesPerGroup; l++) {
      float normalizedLineIndex = float(l) / float(linesPerGroup);
      float offsetTime          = iTime * offsetSpeed;
      float offsetPosition      = float(l) + space.x * offsetFrequency;
      float rand                = random(offsetPosition + offsetTime) * 0.5 + 0.5;
      float halfWidth           = mix(minLineWidth, maxLineWidth, rand * horizontalFade) / 2.0;
      float offset              = random(offsetPosition + offsetTime * (1.0 + normalizedLineIndex))
                                  * mix(minOffsetSpread, maxOffsetSpread, horizontalFade);
      float linePosition        = getPlasmaY(space.x, horizontalFade, offset);
      float line                = drawSmoothLine(linePosition, halfWidth, space.y) / 2.0
                                + drawCrispLine(linePosition, halfWidth * 0.15, space.y);

      float circleX        = mod(float(l) + iTime * lineSpeed, 25.0) - 12.0;
      vec2  circlePosition = vec2(circleX, getPlasmaY(circleX, horizontalFade, offset));
      float circle         = drawCircle(circlePosition, 0.01, space) * 4.0;

      vec4 lineCol = mix(brandCyan, brandViolet, normalizedLineIndex);
      line  += circle;
      lines += line * lineCol * rand * 0.75;
      lineMask += line * rand * 0.75;
    }

    fragColor    = mix(bgColor1, bgColor2, uv.x);
    float lightEdge = mix(0.92, 1.0, verticalFade);
    fragColor.rgb *= mix(lightEdge, verticalFade, uEdgeFade);
    fragColor.a  = 1.0;
    float visibleLine = clamp(lineMask, 0.0, 0.82);
    vec3 lineHue = clamp(lines.rgb / max(lineMask, 0.001), 0.0, 1.0);
    vec3 lightResult = mix(fragColor.rgb, lineHue, visibleLine);
    vec3 darkResult = fragColor.rgb + lines.rgb;
    fragColor.rgb = mix(lightResult, darkResult, uEdgeFade);

    gl_FragColor = fragColor;
  }
`;

// ── WebGL helpers (pure functions, no React) ─────────────────────────────────

function compileShader(gl, type, source) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.error('Shader compile error:', gl.getShaderInfoLog(shader));
    gl.deleteShader(shader);
    return null;
  }
  return shader;
}

function createProgram(gl, vsSrc, fsSrc) {
  const vs = compileShader(gl, gl.VERTEX_SHADER,   vsSrc);
  const fs = compileShader(gl, gl.FRAGMENT_SHADER, fsSrc);
  if (!vs || !fs) return null;
  const program = gl.createProgram();
  gl.attachShader(program, vs);
  gl.attachShader(program, fs);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.error('Program link error:', gl.getProgramInfoLog(program));
    return null;
  }
  return program;
}

// ── Component ─────────────────────────────────────────────────────────────────

import { useEffect, useRef } from 'react';

const THEME_PALETTES = {
  dark: {
    backgroundStart: [12 / 255, 28 / 255, 51 / 255],
    backgroundEnd: [5 / 255, 11 / 255, 20 / 255],
    lineStart: [120 / 255, 167 / 255, 255 / 255],
    lineEnd: [201 / 255, 242 / 255, 126 / 255],
    edgeFade: 1,
  },
  light: {
    backgroundStart: [246 / 255, 248 / 255, 245 / 255],
    backgroundEnd: [238 / 255, 242 / 255, 238 / 255],
    lineStart: [23 / 255, 86 / 255, 217 / 255],
    lineEnd: [111 / 255, 151 / 255, 48 / 255],
    edgeFade: 0,
  },
};

const COLOR_TRANSITION_MS = 900;
const mixColor = (from, to, progress) => from.map((value, index) => value + (to[index] - value) * progress);
const easeOutCubic = (value) => 1 - Math.pow(1 - value, 3);

export default function AnoAI({ style, className }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let rafId;
    let ro;
    let io;
    let timerId;
    let onVisibilityChange;
    let themeObserver;

    const init = () => {
      const gl = canvas.getContext('webgl');
      if (!gl) return;

      const program = createProgram(gl, VS_SOURCE, FS_SOURCE);
      if (!program) return;

      const positionBuffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
      gl.bufferData(
        gl.ARRAY_BUFFER,
        new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]),
        gl.STATIC_DRAW
      );

      const vertexLoc     = gl.getAttribLocation(program,  'aVertexPosition');
      const resolutionLoc = gl.getUniformLocation(program, 'iResolution');
      const timeLoc       = gl.getUniformLocation(program, 'iTime');
      const backgroundStartLoc = gl.getUniformLocation(program, 'uBackgroundStart');
      const backgroundEndLoc = gl.getUniformLocation(program, 'uBackgroundEnd');
      const lineStartLoc = gl.getUniformLocation(program, 'uLineStart');
      const lineEndLoc = gl.getUniformLocation(program, 'uLineEnd');
      const edgeFadeLoc = gl.getUniformLocation(program, 'uEdgeFade');

      // ── Performance стратегия (анимацията НИКОГА не спира) ──────────────
      // 1) Half-resolution: canvas вътрешно е 50% по-малък, CSS го scale-ва
      //    обратно. Hero обвивката има filter: blur(2.5px), което прави
      //    загубата на резолюция визуално невидима. → 4× по-малко fragment
      //    shader работа.
      // 2) 30 FPS throttle: пропускаме всеки втори кадър. Ambient ефекти
      //    изглеждат еднакво гладко при 30fps. → 2× по-малко GPU работа.
      // 3) Pause при scroll-out (IntersectionObserver) — спираме draw-а
      //    когато hero е извън viewport-а. Винаги възобновяваме при scroll-in.
      // 4) Pause при tab не на фокус (Page Visibility API) — спираме draw-а
      //    при minimized/background tab.
      //
      // Общо: ~8× по-малко GPU/compositor работа vs наивна имплементация.

      const RESOLUTION_SCALE = 0.5;
      const TARGET_FPS = 30;
      const FRAME_INTERVAL_MS = 1000 / TARGET_FPS;

      const resize = () => {
        const { width, height } = canvas.getBoundingClientRect();
        const targetW = Math.round(width  * RESOLUTION_SCALE);
        const targetH = Math.round(height * RESOLUTION_SCALE);
        if (canvas.width !== targetW || canvas.height !== targetH) {
          canvas.width  = targetW;
          canvas.height = targetH;
          gl.viewport(0, 0, targetW, targetH);
        }
      };

      ro = new ResizeObserver(resize);
      ro.observe(canvas);
      resize();

      const startTime = Date.now();
      let lastFrameTime = 0;
      let isVisible = true;       // hero в viewport
      let isTabFocused = !document.hidden;
      let isRendering = false;
      const initialTheme = document.documentElement.dataset.theme === 'light' ? 'light' : 'dark';
      let currentPalette = THEME_PALETTES[initialTheme];
      let fromPalette = currentPalette;
      let targetPalette = currentPalette;
      let colorTransitionStartedAt = 0;

      const resolvePalette = (now) => {
        const rawProgress = colorTransitionStartedAt
          ? Math.min((now - colorTransitionStartedAt) / COLOR_TRANSITION_MS, 1)
          : 1;
        const progress = easeOutCubic(rawProgress);
        const resolved = {
          backgroundStart: mixColor(fromPalette.backgroundStart, targetPalette.backgroundStart, progress),
          backgroundEnd: mixColor(fromPalette.backgroundEnd, targetPalette.backgroundEnd, progress),
          lineStart: mixColor(fromPalette.lineStart, targetPalette.lineStart, progress),
          lineEnd: mixColor(fromPalette.lineEnd, targetPalette.lineEnd, progress),
          edgeFade: fromPalette.edgeFade + (targetPalette.edgeFade - fromPalette.edgeFade) * progress,
        };
        currentPalette = resolved;
        return resolved;
      };

      themeObserver = new MutationObserver(() => {
        const nextTheme = document.documentElement.dataset.theme === 'light' ? 'light' : 'dark';
        const now = performance.now();
        fromPalette = resolvePalette(now);
        targetPalette = THEME_PALETTES[nextTheme];
        colorTransitionStartedAt = now;
        startLoop();
      });
      themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

      const drawFrame = (now) => {
        const t = (Date.now() - startTime) / 1000;
        const palette = resolvePalette(now);
        gl.clearColor(0, 0, 0, 1);
        gl.clear(gl.COLOR_BUFFER_BIT);
        gl.useProgram(program);
        gl.uniform2f(resolutionLoc, canvas.width, canvas.height);
        gl.uniform1f(timeLoc, t);
        gl.uniform3fv(backgroundStartLoc, palette.backgroundStart);
        gl.uniform3fv(backgroundEndLoc, palette.backgroundEnd);
        gl.uniform3fv(lineStartLoc, palette.lineStart);
        gl.uniform3fv(lineEndLoc, palette.lineEnd);
        gl.uniform1f(edgeFadeLoc, palette.edgeFade);
        gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
        gl.vertexAttribPointer(vertexLoc, 2, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(vertexLoc);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      };

      const renderLoop = (now) => {
        if (!isVisible || !isTabFocused) {
          isRendering = false;
          return; // pause loop напълно — нула GPU работа
        }
        // 30fps throttle — пропускаме кадри ако не е минал интервалът
        if (now - lastFrameTime >= FRAME_INTERVAL_MS) {
          drawFrame(now);
          lastFrameTime = now;
        }
        rafId = requestAnimationFrame(renderLoop);
      };

      const startLoop = () => {
        if (isRendering) return;
        if (!isVisible || !isTabFocused) return;
        isRendering = true;
        lastFrameTime = 0; // force immediate first frame
        rafId = requestAnimationFrame(renderLoop);
      };

      // IntersectionObserver — pause/resume при scroll
      io = new IntersectionObserver(([entry]) => {
        isVisible = entry.isIntersecting;
        if (isVisible) startLoop();
      }, { threshold: 0 });
      io.observe(canvas);

      // Page Visibility — pause при minimized/background tab
      onVisibilityChange = () => {
        isTabFocused = !document.hidden;
        if (isTabFocused) startLoop();
      };
      document.addEventListener('visibilitychange', onVisibilityChange);

      startLoop();
    };

    // Defer shader compilation until after the main thread is idle so LCP (H1) can paint first.
    // requestIdleCallback guarantees we don't compete for main-thread time at startup.
    // Fallback to a generous setTimeout for browsers without rIC (e.g. Safari < 16).
    if ("requestIdleCallback" in window) {
      timerId = requestIdleCallback(init, { timeout: 4000 });
    } else {
      timerId = setTimeout(init, 1500);
    }

    return () => {
      if ("requestIdleCallback" in window && typeof timerId === "number") {
        cancelIdleCallback(timerId);
      } else {
        clearTimeout(timerId);
      }
      if (rafId) cancelAnimationFrame(rafId);
      if (ro) ro.disconnect();
      if (io) io.disconnect();
      if (themeObserver) themeObserver.disconnect();
      if (onVisibilityChange) document.removeEventListener('visibilitychange', onVisibilityChange);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className={className}
      style={{
        position: 'absolute',
        inset: 0,
        width: '100%',
        height: '100%',
        display: 'block',
        pointerEvents: 'none',
        ...style,
      }}
    />
  );
}
