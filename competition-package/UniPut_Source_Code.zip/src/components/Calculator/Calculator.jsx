import { useState, useEffect, useMemo, useRef } from "react";
import { m, AnimatePresence } from "motion/react";
import { supabase } from "@/lib/supabase";
import { fetchDistinct } from "@/services/universityService";
import { assessFormula } from "@/lib/formulaIntegrity";
import { admissionSource } from "@/lib/admissionSources";
import { calculateScore, findSeparateDiplomaKeys, isValidGradeValue } from "@/lib/scoring";
import { useLocation, Link } from "react-router-dom";
import Seo from "@/components/common/Seo";
import JsonLd from "@/components/common/JsonLd";
import AccreditationWarning from "@/components/common/AccreditationWarning";
import { useAuth } from "@/hooks/useAuth";

// HowTo schema — Google rich result за стъпковите процеси.
// Прави калкулатора eligible за show-eshte със стъпки в SERP.
const CALCULATOR_SCHEMA = {
    "@context": "https://schema.org",
    "@type": "HowTo",
    name: "Как да изчислиш кандидатстудентския си бал",
    description: "Стъпки за изчисление на приемен бал по правилата на избрания университет",
    totalTime: "PT2M",
    step: [
        { "@type": "HowToStep", position: 1, name: "Избери факултет", text: "Изберете факултета, в който искате да кандидатствате." },
        { "@type": "HowToStep", position: 2, name: "Избери специалност", text: "Изберете конкретната специалност от списъка." },
        { "@type": "HowToStep", position: 3, name: "Въведи оценките", text: "Въведете оценките от диплома, матура (ДЗИ) и кандидатстудентски изпити." },
        { "@type": "HowToStep", position: 4, name: "Виж приемния бал", text: "Калкулаторът прилага официалните коефициенти и показва резултата ви спрямо историческия праг за прием." },
    ],
};
import {
    Calculator,
    TrendingUp,
    TrendingDown,
    Info,
    CheckCircle2,
    XCircle,
    ChevronDown,
    AlertCircle,
    BookOpen,
    GraduationCap,
    Star,
    ArrowRight,
    Lightbulb,
    Target,
    Zap,
    Copy,
    Check,
    Share2,
    Download,
    ExternalLink,
    Bookmark,
    X as XIcon,
    UserPlus,
    Compass,
    Lock,
    Users,
} from "lucide-react";
import GradeInputSection from "./GradeInputSection";
import DeadlineReminder from "@/components/common/DeadlineReminder";
import { calcStatsService } from "@/services/calcStatsService";
import { CALC_HISTORY_KEY, historyKey, nextHistoryPoints, readLocalHistory, CHANCE_BAND_META, CHANCE_TONES } from "@/lib/calcHistory";
import { copyText, wrapText, roundRect, shareOrCopyLink, shareOrDownloadCanvas } from "@/lib/shareCard";
import ReportButton from "./ReportButton";
import PlovdivCalculator from "./PlovdivCalculator";
import { plovdivProgram } from "@/lib/plovdivScore";
import VfuCalculator from "./VfuCalculator";
import { vfuProgram } from "@/lib/vfuScore";
import NbuCalculator from "./NbuCalculator";
import { nbuProgram } from "@/lib/nbuScore";
import UardCalculator from "./UardCalculator";
import { uardProgram } from "@/lib/uardScore";
import TourismCollegeCalculator from "./TourismCollegeCalculator";
import { tourismCollegeProgram } from "@/lib/tourismCollegeScore";
import NmaCalculator from "./NmaCalculator";
import { nmaProgram } from "@/lib/nmaScore";
import { FIELD_LABELS, SLOT_GROUPS } from "@/lib/coefficients_config";
import { UNIVERSITIES, SPECIALTIES, ADMISSION_YEAR, ADMISSION_YEAR_SHORT, DATA_FRESHNESS_NOTE } from "@/lib/siteStats";

const SAFE_ORIGIN = import.meta.env.VITE_APP_URL || window.location.origin;

// Reciprocity + certainty (ux-psychology): първите GATE_LIMIT различни
// специалности, за които анонимен потребител вижда пълен резултат, са
// безплатни и НЕ се замъгляват — резултатът е истински, не примамка. Отвъд
// прага искаме акаунт, за да не губи прогреса си (loss aversion, честна
// версия): балът се пази само на този браузър.
const GATE_LIMIT = 3;
const STATS_DEBOUNCE_MS = 2500;

const S = {
    surface: "var(--brand-surface-2)",
    border: "var(--brand-border)",
    input: {
        background: "var(--brand-input-bg)",
        border: "1px solid var(--brand-input-border)",
        borderRadius: "0.75rem",
        color: "var(--brand-text)",
        fontSize: "14px",
        fontWeight: 500,
        outline: "none",
        fontFamily: "inherit",
        height: "3rem",
        padding: "0 1rem",
        width: "100%",
        boxSizing: "border-box",
        transition: "border-color 0.2s",
    },
};

// ── How it works steps ──────────────────────────────────────────────────────
const HOW_STEPS = [
    { icon: BookOpen,      num: "01", title: "Избери факултет",   desc: "Напиши или избери факултета, за който искаш да кандидатстваш. Можеш да търсиш по ключова дума." },
    { icon: GraduationCap, num: "02", title: "Избери специалност", desc: "От наличните специалности за избрания факултет, изберете тази, която ви интересува." },
    { icon: Star,          num: "03", title: "Въведи оценките",   desc: "Въведи своите оценки от матурата и дипломата. Калкулаторът автоматично прилага коефициентите." },
    { icon: Target,        num: "04", title: "Виж резултата",     desc: "Получаваш своя конкурсен бал и сравнение с историческия среден бал за прием." },
];

// ── DZI points → grade conversion ───────────────────────────────────────────
const DZI_BANDS = [
    { min: 0,     max: 29.75, label: "Слаб",        grade_min: 2.00, grade_max: 2.00, color: "var(--danger)", bg: "var(--danger-bg)", border: "color-mix(in srgb, var(--danger) 34%, transparent)" },
    { min: 30,    max: 40.5,  label: "Среден",      grade_min: 3.00, grade_max: 3.99, color: "var(--c-rust)", bg: "color-mix(in srgb, var(--c-rust) 10%, transparent)", border: "color-mix(in srgb, var(--c-rust) 32%, transparent)" },
    { min: 40.75, max: 62.25, label: "Добър",       grade_min: 4.00, grade_max: 4.99, color: "var(--warning)", bg: "var(--warning-bg)", border: "color-mix(in srgb, var(--warning) 34%, transparent)" },
    { min: 62.5,  max: 83.75, label: "Много добър", grade_min: 5.00, grade_max: 5.49, color: "var(--brand-cyan)", bg: "var(--brand-subtle)", border: "color-mix(in srgb, var(--brand-cyan) 32%, transparent)" },
    { min: 84,    max: 94.75, label: "Отличен",     grade_min: 5.50, grade_max: 5.99, color: "var(--brand-cyan)", bg: "var(--brand-subtle)", border: "color-mix(in srgb, var(--brand-cyan) 32%, transparent)" },
    { min: 95,    max: 100,   label: "Отличен 6",   grade_min: 6.00, grade_max: 6.00, color: "var(--success)", bg: "var(--success-bg)", border: "color-mix(in srgb, var(--success) 34%, transparent)" },
];

function dziToGrade(pts) {
    const p = Math.max(0, Math.min(100, pts));
    // Bug fix: DZI_BANDS имат микро-gap-ове между upper bound и следващото lower bound
    // (напр. 83.75 → 84). Стойности като 83.8, 29.8, 40.6, 62.3, 94.8 пропадаха
    // в дупките и find() връщаше undefined → fallback на "Слаб" (грешка от user).
    // Решение: проверявай долна граница на ТЕКУЩАТА и долна граница на СЛЕДВАЩАТА band.
    const band = DZI_BANDS.find((b, i) => {
        const next = DZI_BANDS[i + 1];
        return p >= b.min && (next ? p < next.min : p <= b.max);
    }) ?? DZI_BANDS[0];
    let grade;
    if (band.grade_min === band.grade_max) {
        grade = band.grade_min;
    } else {
        // Clamp t in [0, 1] за да не overflow-ва grade при точки точно на upper bound.
        const t = Math.min(1, Math.max(0, (p - band.min) / (band.max - band.min)));
        grade = band.grade_min + t * (band.grade_max - band.grade_min);
    }
    return { grade: +grade.toFixed(2), band };
}

// ── Шанс за прием ────────────────────────────────────────────────────────────
// Качествен ориентир, НЕ процент. Одитите са изрични: с ~1 година история на
// повечето програми не може да се твърди статистическа вероятност. Показваме
// лента спрямо миналогодишния праг, нормализирана към max_ball на програмата
// (иначе „+5 т." значи различно на скала /42 и на /500).
// Годишните колебания на минималния бал са около 15–20% от max_ball, затова
// „на границата" е широка лента, а не точка.
// Блърбовете остават тук (само калкулаторът ги показва); етикет+цвят идват
// от CHANCE_BAND_META, за да не се разминат с картата в Любими.
const CHANCE_BLURBS = {
    high: "Балът ти е доста над миналогодишния праг — с голяма преднина.",
    good: "Балът ти е над миналогодишния праг с удобна разлика.",
    realistic: "Балът ти е на границата на миналогодишния праг — може да падне и в двете посоки.",
    borderline: "Балът ти е под миналогодишния праг, но в рамките на обичайните годишни колебания.",
    low: "Балът ти е доста под миналогодишния праг. Подготви и резервни варианти.",
};

function admissionChanceBand(score, minBall, maxBall) {
    if (!(score > 0) || minBall == null || !(maxBall > 0)) return null;
    const marginPts = score - minBall;
    const marginPct = (marginPts / maxBall) * 100;
    const key = marginPct >= 12 ? "high"
        : marginPct >= 4 ? "good"
        : marginPct >= -2 ? "realistic"
        : marginPct >= -10 ? "borderline"
        : "low";
    return { key, ...CHANCE_BAND_META[key], blurb: CHANCE_BLURBS[key] };
}

// ── Споделяне на резултат ────────────────────────────────────────────────────
// Growth move (CLAUDE.md §11): моментът след разкриване на бала е най-силният
// за споделяне. Дава се (1) линк, който отваря калкулатора със същата
// специалност — приятелят въвежда СВОИ оценки (нула PII в URL-а), и (2) канава
// картинка за screenshot в Viber/WhatsApp/Instagram.

function buildShareUrl(specialty, university) {
    const p = new URLSearchParams({ specialty });
    if (university) p.set("university", university);
    return `${window.location.origin}/calculator/?${p.toString()}`;
}

// Рисува 1080×1350 (4:5) картинка на резултата — без външни шрифтове/asset-и,
// за да е надеждно във всеки браузър. Връща canvas.
function drawCalcResultCard({ university, specialty, score, maxBall, chance, marginPts, minBall, minYear }) {
    const W = 1080;
    const PAD = 88;
    const INNER = W - PAD * 2;
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    const font = (size, weight = 400) =>
        `${weight} ${size}px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif`;
    const mono = (size, weight = 400) =>
        `${weight} ${size}px ui-monospace, "SF Mono", Menlo, Consolas, monospace`;

    // ── Фаза 1: пресмятаме реда, за да оразмерим канавата по съдържанието
    ctx.font = font(28, 600);
    const uniLines = wrapText(ctx, university, INNER).slice(0, 2);
    ctx.font = font(58, 800);
    const specLines = wrapText(ctx, specialty, INNER).slice(0, 2);

    const LOGO_BLOCK = 96;
    const uniH = uniLines.length * 40;
    const specH = specLines.length * 70;
    const scoreBlockH = 176 + 56;      // число + подредове
    const bandH = chance ? 200 : 0;
    const bandGap = chance ? 56 : 0;
    const contentH = LOGO_BLOCK + 34 + uniH + 20 + specH + 48 + scoreBlockH + bandGap + bandH;
    const FOOTER = 90;
    const H = Math.round(PAD + contentH + FOOTER + PAD);

    canvas.width = W; canvas.height = H;

    // ── Фаза 2: рисуване
    ctx.fillStyle = "#0F172A";
    ctx.fillRect(0, 0, W, H);
    const glow = ctx.createRadialGradient(W * 0.82, H * 0.16, 0, W * 0.82, H * 0.16, W * 0.85);
    glow.addColorStop(0, "rgba(23,86,217,0.16)");
    glow.addColorStop(1, "rgba(23,86,217,0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, W, H);
    ctx.textBaseline = "alphabetic";

    // Лого
    ctx.fillStyle = "#1756D9";
    ctx.fillRect(PAD, PAD, 8, 40);
    ctx.fillStyle = "#F1F5F9";
    ctx.font = font(38, 800);
    ctx.fillText("УниПът", PAD + 24, PAD + 32);

    // Университет + специалност
    let y = PAD + LOGO_BLOCK + 34;
    ctx.fillStyle = "#94A3B8";
    ctx.font = font(28, 600);
    for (const line of uniLines) { ctx.fillText(line, PAD, y); y += 40; }
    y += 20;
    ctx.fillStyle = "#F1F5F9";
    ctx.font = font(58, 800);
    for (const line of specLines) { ctx.fillText(line, PAD, y); y += 70; }

    // Бал — голямо число с cyan→violet градиент
    y += 48 + 176;
    ctx.font = mono(176, 900);
    const scoreText = score.toFixed(2);
    const scoreW = ctx.measureText(scoreText).width;
    const grad = ctx.createLinearGradient(PAD, 0, PAD + scoreW, 0);
    grad.addColorStop(0, "#1756D9");
    grad.addColorStop(1, "#1756D9");
    ctx.fillStyle = grad;
    ctx.fillText(scoreText, PAD, y);
    if (maxBall) {
        ctx.fillStyle = "#64748B";
        ctx.font = font(40, 700);
        ctx.fillText(`/ ${Number(maxBall)}`, PAD + scoreW + 22, y);
    }
    ctx.fillStyle = "#64748B";
    ctx.font = font(24, 700);
    ctx.fillText("КОНКУРСЕН БАЛ", PAD + 4, y + 44);
    if (minBall != null) {
        ctx.fillStyle = "#94A3B8";
        ctx.font = font(26, 500);
        ctx.textAlign = "right";
        ctx.fillText(`минимален бал ${minYear || ""}: ${minBall.toFixed(2)}`, W - PAD, y + 44);
        ctx.textAlign = "left";
    }

    // Лента „шанс за прием"
    if (chance) {
        const tone = { green: "#10b981", amber: "#FBBF24", red: "#f87171" }[chance.tone];
        y += bandGap;
        roundRect(ctx, PAD, y, INNER, bandH, 24);
        ctx.fillStyle = tone + "1A"; // ~10% алфа
        ctx.fill();
        ctx.strokeStyle = tone;
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = "#94A3B8";
        ctx.font = font(24, 700);
        ctx.fillText("ШАНС ЗА ПРИЕМ", PAD + 44, y + 56);
        ctx.fillStyle = tone;
        ctx.font = font(56, 800);
        ctx.fillText(chance.label, PAD + 44, y + 118);
        if (marginPts != null) {
            ctx.fillStyle = "#94A3B8";
            ctx.font = font(28, 600);
            const sign = marginPts >= 0 ? "+" : "−";
            ctx.fillText(`${sign}${Math.abs(marginPts).toFixed(2)} т. спрямо миналогодишния праг`, PAD + 44, y + 162);
        }
    }

    // Футър
    ctx.fillStyle = "#64748B";
    ctx.font = font(28, 700);
    ctx.fillText("uniput.eu", PAD, H - PAD);
    ctx.fillStyle = "#94A3B8";
    ctx.font = font(26, 500);
    ctx.textAlign = "right";
    ctx.fillText("Изчисли своя бал безплатно", W - PAD, H - PAD);
    ctx.textAlign = "left";

    return canvas;
}

// ── Formula legend ───────────────────────────────────────────────────────────
const FORMULA_LEGEND = [
    { symbol: "Изпит(X)",  desc: "Конкурсен изпит по предмет X, организиран от университета" },
    { symbol: "ДЗИ(X)",    desc: "Държавен зрелостен изпит (матура) по предмет X" },
    { symbol: "ДЗИ¹ / ДЗИ²", desc: "Първи или втори зрелостен изпит (когато са различни предмети)" },
    { symbol: "X(д)",      desc: "Оценка по предмет X от дипломата за средно образование" },
    { symbol: "СО",        desc: "Среден успех (средноаритметична оценка) от дипломата" },
    { symbol: "×N",        desc: "Коефициент N — оценката се умножава по N преди събиране" },
    { symbol: "/",         desc: "ИЛИ — взима се резултатът с по-висока стойност" },
    { symbol: "+",         desc: "И — двата компонента се сумират (задължителни)" },
];

// ── Tips ────────────────────────────────────────────────────────────────────
const TIPS = [
    "Коефициентите се прилагат автоматично — не е нужно да ги пресмяташ ръчно.",
    "Ако имаш оценки от два различни изпита за едно и също поле, въведи и двете — калкулаторът взима по-високата.",
    "Средният бал за прием се изчислява от максималния разделен на две.",
    "Можеш да сравниш един и същи факултет в различни университети и градове.",
    "Пазете своя RIASEC профил — той ще ти помогне да намериш специалности, подходящи за теб.",
];

// Кеш в паметта: данни за факултет + минимални балове (живее до презареждане на страницата).
const FACULTY_DATA_CACHE = new Map();

function AdmissionSourceNote({ row }) {
    const source = admissionSource(row);
    if (!source) return null;
    const verifiedDate = source.verifiedAt
        ? new Intl.DateTimeFormat("bg-BG", { dateStyle: "medium" }).format(new Date(source.verifiedAt))
        : null;

    return (
        <div className="mb-4 flex items-start gap-2 rounded-xl border border-[var(--brand-card-border)] bg-[var(--brand-surface)] px-4 py-3 text-xs text-[var(--brand-muted)]">
            <ExternalLink size={14} className="mt-0.5 shrink-0 text-[var(--brand-cyan)]" />
            <div>
                <a className="font-bold text-[var(--brand-cyan)] underline underline-offset-4" href={source.url} target="_blank" rel="noopener noreferrer">
                    {source.label}
                </a>
                <div className="mt-1">
                    {verifiedDate ? `Формулата е сверена на ${verifiedDate}.` : "Официален източник е наличен; формулата очаква ръчна проверка."}
                </div>
            </div>
        </div>
    );
}

export default function CalculatorPage() {
    const [allData, setAllData] = useState([]);
    const [minScores, setMinScores] = useState({}); // university_id → {minBall, minBallMax, year, round}
    const [faculties, setFaculties] = useState([]);
    const [selectedFaculty, setSelectedFaculty] = useState("");
    const [selectedCity, setSelectedCity] = useState("");
    const [selectedUniversity, setSelectedUniversity] = useState("");
    const [facultySearch, setFacultySearch] = useState("");
    const [isFacultyDropdownOpen, setIsFacultyDropdownOpen] = useState(false);
    const [dropdownShowAll, setDropdownShowAll] = useState(false);
    const [selectedSpecialtyName, setSelectedSpecialtyName] = useState("");
    const [grades, setGrades] = useState({});
    const [pendingSpecialty, setPendingSpecialty] = useState(null);
    const [dziPoints, setDziPoints] = useState("");
    const [dziError, setDziError] = useState("");
    const [copied, setCopied] = useState(false);
    const [shareFeedback, setShareFeedback] = useState(null); // { id, kind: "link" | "image" }
    const [loadError, setLoadError] = useState(null);
    const location = useLocation();
    const { user } = useAuth();
    // Signup prompt — показва се само за анонимни потребители след първи изчислен бал.
    // Dismissal се пази в localStorage за да не дразним потребителя при повторно посещение.
    const [signupCardDismissed, setSignupCardDismissed] = useState(() => {
        try { return localStorage.getItem("calc_signup_dismissed") === "1"; } catch { return false; }
    });
    const dismissSignupCard = () => {
        setSignupCardDismissed(true);
        try { localStorage.setItem("calc_signup_dismissed", "1"); } catch { /* localStorage недостъпен */ }
    };

    // Gate A (ux-psychology): кои специалности анонимният потребител вече е
    // „отключил" (получил е пълен резултат за тях). Пазим пълните записи (не
    // само ключове), за да можем да покажем имената им в gate картата —
    // инициализира се от localStorage, за да оцелее презареждане на страницата.
    const [unlockedHistory, setUnlockedHistory] = useState(readLocalHistory);
    const unlockedSpecialtyKeys = useMemo(() => new Set(unlockedHistory.map(historyKey)), [unlockedHistory]);

    // OAuth директно от gate картата — връща потребителя на СЪЩАТА заключена
    // специалност (certainty: нищо не се губи), не на общ /calculator.
    const handleGateGoogleSignup = () => {
        const dest = `${location.pathname}${location.search}`;
        supabase.auth.signInWithOAuth({
            provider: "google",
            options: { redirectTo: `${SAFE_ORIGIN}${dest}` },
        });
    };

    const handleDziChange = (e) => {
        const val = e.target.value;
        setDziPoints(val);
        if (val === "" || val === "-") { setDziError(""); return; }
        const num = parseFloat(val);
        if (isNaN(num)) {
            setDziError("Въведи валидно число.");
        } else if (num < 0) {
            setDziError("Точките не могат да са отрицателни.");
        } else if (num > 100) {
            setDziError("Максималният брой точки е 100.");
        } else {
            setDziError("");
        }
    };

    const dziResult = dziPoints !== "" && !dziError && !isNaN(parseFloat(dziPoints))
        ? dziToGrade(parseFloat(dziPoints))
        : null;

    const copyGrade = () => {
        if (!dziResult) return;
        copyText(String(dziResult.grade));
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const flashShare = (id, kind) => {
        setShareFeedback({ id, kind });
        setTimeout(() => setShareFeedback(f => (f && f.id === id ? null : f)), 2400);
    };

    const shareResult = async (res) => {
        const { item, score, chance } = res;
        const url = buildShareUrl(item.specialty, item.university_name);
        const verdict = chance ? ` — ${chance.label.toLowerCase()}` : "";
        const text = `Моят приемен бал за ${item.specialty} (${item.university_name}): ${score.toFixed(2)}${verdict}. Изчисли своя:`;
        const outcome = await shareOrCopyLink({ title: "УниПът — приемен бал", text, url });
        if (outcome === "copied") flashShare(item.id, "link");
    };

    const saveResultImage = async (res) => {
        const { item, score, maxBall, chance, marginPts, minScore } = res;
        const canvas = drawCalcResultCard({
            university: item.university_name,
            specialty: item.specialty,
            score,
            maxBall,
            chance,
            marginPts,
            minBall: minScore?.minBall ?? null,
            minYear: minScore?.year ?? null,
        });
        const fileName = `uniput-bal-${item.specialty}.png`.replace(/\s+/g, "-");
        const outcome = await shareOrDownloadCanvas(canvas, fileName, "УниПът — приемен бал");
        if (outcome === "downloaded") flashShare(item.id, "image");
    };

    const cities = useMemo(
        () => [...new Set(allData.map(d => d.city).filter(Boolean))].sort(),
        [allData]
    );
    const universities = useMemo(
        () => [...new Set(allData.map(d => d.university_name).filter(Boolean))].sort(),
        [allData]
    );

    const filteredFaculties = useMemo(() => {
        if (dropdownShowAll || !facultySearch) return faculties;
        return faculties.filter(f => f.toLowerCase().includes(facultySearch.toLowerCase()));
    }, [faculties, facultySearch, dropdownShowAll]);

    const filteredData = useMemo(() => allData.filter(d => {
        const matchFaculty = !selectedFaculty || d.faculty === selectedFaculty;
        const matchCity = !selectedCity || d.city === selectedCity;
        const matchUni = !selectedUniversity || d.university_name === selectedUniversity;
        return matchFaculty && matchCity && matchUni;
    }), [allData, selectedFaculty, selectedCity, selectedUniversity]);

    const availableSpecialties = useMemo(
        () => [...new Set(filteredData.map(d => d.specialty))].sort(),
        [filteredData]
    );

    useEffect(() => {
        (async () => {
            try {
                const cached = localStorage.getItem("uniput_faculties_cache_v2");
                if (cached) {
                    const parsed = JSON.parse(cached);
                    if (Array.isArray(parsed) && parsed.length > 0) setFaculties(parsed);
                }
            } catch {
                // corrupt cache — игнорираме, ще се презапише
            }
            let list;
            let error = null;
            try { list = await fetchDistinct("faculty"); } catch (e) { error = e; }
            if (error) {
                // Ако вече имаме факултети от cache-а — продължаваме да работим без да тревожим UI.
                // Ако нямаме — показваме грешка.
                setFaculties(prev => {
                    if (!prev.length) setLoadError("Не успяхме да заредим факултетите. Провери връзката и опитай пак.");
                    return prev;
                });
                return;
            }
            setFaculties(list);
            setLoadError(null);
            try { localStorage.setItem("uniput_faculties_cache_v2", JSON.stringify(list)); } catch {
                // localStorage недостъпен / пълен
            }
        })();
    }, []);

    useEffect(() => {
        if (!selectedFaculty) return;
        // Повторен избор на същия факултет не прави нови заявки.
        const hit = FACULTY_DATA_CACHE.get(selectedFaculty);
        if (hit) {
            setAllData(hit.rows);
            setMinScores(hit.minScores);
            setLoadError(null);
            return;
        }
        let current = true;
        setAllData([]);
        setMinScores({});
        setLoadError(null);
        (async () => {
            const { data, error } = await supabase
                .from("universities")
                .select("id,faculty,specialty,university_name,city,coefficients,formula_description,max_ball,website_url,accreditation_status,source_url,source_publisher,verified_at")
                .eq("academic_year", ADMISSION_YEAR)
                .eq("faculty", selectedFaculty)
                .limit(500);
            if (!current) return;
            if (error) {
                setLoadError("Не успяхме да заредим специалностите за този факултет. Опитай отново.");
                setAllData([]);
                return;
            }
            setAllData(data || []);
            setLoadError(null);
            let resolvedMin = {};

            // Официални минимални балове от класиране (где са публикувани).
            // Отделна slim заявка — не пипаме основната, кешираме по запис.
            const ids = (data || []).map(r => r.id);
            if (ids.length) {
                const { data: msData, error: msError } = await supabase
                    .from("admission_min_scores")
                    .select("university_id,year,round,min_ball,quota")
                    .in("university_id", ids);
                if (!current) return;
                if (!msError && msData?.length) {
                    const byId = {};
                    msData.forEach(r => { (byId[r.university_id] ||= []).push(r); });
                    const resolved = {};
                    Object.entries(byId).forEach(([id, rows]) => {
                        // Последна година → НАЙ-РАННО класиране. Първото класиране е ориентирът,
                        // към който се цели кандидатът; по-късните класирания запълват остатъчни
                        // места и дават по-нисък, подвеждащо оптимистичен праг.
                        // null round = финално/неуточнено → използва се само ако няма номерирано.
                        const latestYear = Math.max(...rows.map(r => r.year));
                        const yearRows = rows.filter(r => r.year === latestYear);
                        const roundRank = r => (r.round === null ? 99 : r.round);
                        const bestRound = Math.min(...yearRows.map(roundRank));
                        const finalRows = yearRows.filter(r => roundRank(r) === bestRound);
                        const values = finalRows.map(r => Number(r.min_ball)).filter(v => Number.isFinite(v) && v > 0);
                        if (!values.length) return;
                        resolved[id] = {
                            minBall: Math.min(...values),          // прагът = най-ниският приет бал
                            minBallMax: Math.max(...values),       // при квоти (жени/мъже) — горен край на диапазона
                            year: latestYear,
                            round: finalRows[0].round,
                        };
                    });
                    resolvedMin = resolved;
                }
            }
            setMinScores(resolvedMin);
            FACULTY_DATA_CACHE.set(selectedFaculty, { rows: data || [], minScores: resolvedMin });
        })();
        return () => { current = false; };
    }, [selectedFaculty]);

    useEffect(() => {
        const params = new URLSearchParams(location.search);
        const sp = params.get("specialty")?.slice(0, 200).replace(/[%_\\]/g, "");
        const uni = params.get("university")?.slice(0, 300).replace(/[%_\\]/g, "");
        if (!sp) return;
        (async () => {
            // Ако имаме и university — exact match (избягваме грешен hit от ilike при близки имена).
            let q = supabase.from("universities").select("faculty,specialty,university_name")
                .eq("academic_year", ADMISSION_YEAR);
            if (uni) {
                q = q.eq("specialty", sp).eq("university_name", uni);
            } else {
                q = q.ilike("specialty", `%${sp}%`);
            }
            const { data, error } = await q.limit(1);
            if (error || !data?.length) return;
            const match = data[0];
            setPendingSpecialty(match.specialty);
            setSelectedFaculty(match.faculty);
            setFacultySearch(match.faculty);
            if (uni) setSelectedUniversity(match.university_name);
        })();
    }, [location.search]);

    useEffect(() => {
        if (!pendingSpecialty || !allData.length) return;
        if (allData.find(d => d.specialty === pendingSpecialty)) {
            setSelectedSpecialtyName(pendingSpecialty);
            setPendingSpecialty(null);
        }
    }, [allData, pendingSpecialty]);

    useEffect(() => {
        setIsFacultyDropdownOpen(false);
        setDropdownShowAll(false);
    }, [location.pathname]);

    useEffect(() => {
        const onKey = e => { if (e.key === "Escape") { setIsFacultyDropdownOpen(false); setDropdownShowAll(false); } };
        window.addEventListener("keydown", onKey);
        return () => window.removeEventListener("keydown", onKey);
    }, []);

    const { rowsForSelectedSpecialty, unavailableRows, nbuRows, plovdivRows, vfuRows, uardRows, tourismCollegeRows, nmaRows } = useMemo(() => {
        const rowsForSelectedSpecialty = [];
        const unavailableRows = [];
        const nbuRows = [];
        const plovdivRows = [];
        const vfuRows = [];
        const uardRows = [];
        const tourismCollegeRows = [];
        const nmaRows = [];
        for (const row of filteredData) {
            if (row.specialty !== selectedSpecialtyName) continue;
            const nbu = nbuProgram(row);
            if (nbu) {
                nbuRows.push({ row, program: nbu });
                continue;
            }
            const plovdiv = plovdivProgram(row);
            if (plovdiv) {
                plovdivRows.push({ row, program: plovdiv });
                continue;
            }
            const vfu = vfuProgram(row);
            if (vfu) {
                vfuRows.push({ row, program: vfu });
                continue;
            }
            const uard = uardProgram(row);
            if (uard) {
                uardRows.push({ row, program: uard });
                continue;
            }
            const tourismCollege = tourismCollegeProgram(row);
            if (tourismCollege) {
                tourismCollegeRows.push({ row, program: tourismCollege });
                continue;
            }
            const nma = nmaProgram(row);
            if (nma) {
                nmaRows.push({ row, program: nma });
                continue;
            }
            const { issue } = assessFormula(row);
            if (issue) unavailableRows.push(row);
            else rowsForSelectedSpecialty.push(row);
        }
        return { rowsForSelectedSpecialty, unavailableRows, nbuRows, plovdivRows, vfuRows, uardRows, tourismCollegeRows, nmaRows };
    }, [filteredData, selectedSpecialtyName]);

    const coefficientsForInputs = useMemo(() => {
        const merged = {};
        rowsForSelectedSpecialty.forEach(row => {
            (Array.isArray(row?.coefficients) ? row.coefficients : []).forEach(slot => {
                (slot.alternatives || []).forEach(alt => {
                    if (alt?.key) merged[alt.key] = Number(alt.coef) || 1;
                });
            });
        });
        return merged;
    }, [rowsForSelectedSpecialty]);

    const separateDiplomaKeys = useMemo(() => findSeparateDiplomaKeys(rowsForSelectedSpecialty), [rowsForSelectedSpecialty]);

    const describeGroup = groupId => {
        if (FIELD_LABELS[groupId]) return FIELD_LABELS[groupId];
        if (SLOT_GROUPS[groupId]) {
            const first = SLOT_GROUPS[groupId].find(k => FIELD_LABELS[k]);
            if (first) return FIELD_LABELS[first];
        }
        return groupId;
    };

    const getGroupIdForKey = key => {
        for (const [master, members] of Object.entries(SLOT_GROUPS)) {
            if (members.includes(key)) return master;
        }
        return key;
    };

    const describeMissingTerm = termKeys => {
        const labels = [];
        const seen = new Set();
        termKeys.forEach(key => {
            const label = FIELD_LABELS[key] || describeGroup(getGroupIdForKey(key));
            if (!seen.has(label)) { seen.add(label); labels.push(label); }
        });
        return labels.join(" / ");
    };

    const hasAnyValidGrade = useMemo(() =>
        Object.values(grades).some(isValidGradeValue),
        [grades]
    );

    const calcResults = useMemo(() => {
        if (!rowsForSelectedSpecialty.length) return [];
        return rowsForSelectedSpecialty.map(item => {
            const { score, missingSlots } = calculateScore(item.coefficients, grades);
            const maxBall = Number(item.max_ball) > 0 ? Number(item.max_ball) : null;
            // Тристепенен модел: реален минимум от класиране → сравнение с него;
            // няма публикуван → само % от максималния бал, без „влизаш/не влизаш" присъда.
            const minScore = minScores[item.id] || null;
            const isAbove = minScore ? score >= minScore.minBall : null;
            const marginPts = minScore ? score - minScore.minBall : null;
            const chance = minScore ? admissionChanceBand(score, minScore.minBall, maxBall) : null;
            const percentOfMax = !minScore && maxBall && score > 0 ? Math.min((score / maxBall) * 100, 100) : null;
            const hasStarted = score > 0 || hasAnyValidGrade;
            return { item, score, formatted: score.toFixed(2), minScore, isAbove, marginPts, chance, percentOfMax, maxBall, hasStarted, hasMissing: missingSlots.length > 0, missingSlots };
        });
    }, [rowsForSelectedSpecialty, grades, hasAnyValidGrade, minScores]);

    // Save to calculator history whenever a full score is reached
    useEffect(() => {
        if (!selectedSpecialtyName || !hasAnyValidGrade) return;
        const complete = calcResults.filter(r => r.hasStarted && !r.hasMissing && r.score > 0);
        if (!complete.length) return;
        const currentKey = `${selectedFaculty}||${selectedSpecialtyName}`;
        const alreadyUnlocked = unlockedHistory.some(h => historyKey(h) === currentKey);

        // Gate A hard cap: щом анонимен потребител вече е отключил GATE_LIMIT
        // различни специалности, НЕ persist-ваме нова — иначе gate-ът се
        // „върти" (нова специалност измества стара в last-10 и потребителят
        // заобикаля лимита, просто изчислявайки друга след друга). За вече
        // отключена специалност или за логнат потребител — без промяна.
        if (!user && !alreadyUnlocked && unlockedHistory.length >= GATE_LIMIT) return;

        const best = complete.reduce((a, b) => a.score > b.score ? a : b);
        const score = parseFloat(best.formatted);
        const university = best.item.university_name;
        const existing = unlockedHistory.find(h => historyKey(h) === currentKey);
        const entry = {
            faculty: selectedFaculty,
            specialty: selectedSpecialtyName,
            score,
            university,
            points: nextHistoryPoints(existing, score, university),
            maxBall: best.maxBall,
            minBall: best.minScore?.minBall ?? null,
            minBallYear: best.minScore?.year ?? null,
            isAbove: best.isAbove, // null когато няма публикуван минимален бал
            chanceBand: best.chance?.key ?? null, // low|borderline|realistic|good|high
            date: Date.now(),
        };
        const deduped = unlockedHistory.filter(h => historyKey(h) !== currentKey);
        const next = [entry, ...deduped].slice(0, 10);

        // Guard срещу безкраен render loop: без него ВСЯКО re-render (дори
        // само от повторно въвеждане на СЪЩАТА вече записана оценка) създава
        // нов масив/Set с нова референция → setState → re-render → useMemo
        // строи нов Set → ефектът пак вижда „нова" unlockedSpecialtyKeys
        // референция в deps → изпълнява се пак → React хвърля „Maximum
        // update depth exceeded" (наблюдавано на живо при QA). Сравняваме по
        // съдържание (без `date`), не по референция на обекта.
        const stripDate = (arr) => arr.map((h) => { const clone = { ...h }; delete clone.date; return clone; });
        if (JSON.stringify(stripDate(next)) === JSON.stringify(stripDate(unlockedHistory))) return;

        localStorage.setItem(CALC_HISTORY_KEY, JSON.stringify(next));
        setUnlockedHistory(next);
    }, [calcResults, selectedSpecialtyName, hasAnyValidGrade, selectedFaculty, user, unlockedHistory]);

    const currentSpecialtyKey = selectedFaculty && selectedSpecialtyName ? `${selectedFaculty}||${selectedSpecialtyName}` : null;
    const hasCompleteResult = calcResults.some(r => r.hasStarted && !r.hasMissing && r.score > 0);
    const isSpecialtyLocked = !user
        && !!currentSpecialtyKey
        && hasCompleteResult
        && !unlockedSpecialtyKeys.has(currentSpecialtyKey)
        && unlockedSpecialtyKeys.size >= GATE_LIMIT;

    // Анонимна статистика: след пауза във въвеждането записваме баловете и
    // питаме за процентилен ранг. Под 20 браузъра сървърът не връща нищо.
    // Пазим бала, за който е ранкът — при нови оценки старият не се показва.
    const [cohortStats, setCohortStats] = useState({});
    const lastStatsPayload = useRef("");
    useEffect(() => {
        if (isSpecialtyLocked) return;
        const items = calcResults
            .filter(r => r.hasStarted && !r.hasMissing && r.score > 0)
            .map(r => ({ program_id: r.item.id, score: Number(r.formatted) }));
        if (!items.length) return;
        const payload = JSON.stringify(items);
        if (payload === lastStatsPayload.current) return;
        const timer = setTimeout(async () => {
            lastStatsPayload.current = payload;
            await calcStatsService.record(items);
            const stats = await calcStatsService.percentiles(items);
            const scoreById = Object.fromEntries(items.map(i => [i.program_id, i.score]));
            setCohortStats(prev => {
                const next = { ...prev };
                for (const [id, s] of Object.entries(stats)) next[id] = { ...s, score: scoreById[id] };
                return next;
            });
        }, STATS_DEBOUNCE_MS);
        return () => clearTimeout(timer);
    }, [calcResults, isSpecialtyLocked]);

    const clearFaculty = () => {
        setFacultySearch("");
        setSelectedFaculty("");
        setSelectedSpecialtyName("");
        setSelectedCity("");
        setSelectedUniversity("");
        setIsFacultyDropdownOpen(true);
        setDropdownShowAll(true);
    };

    return (
        <div style={{ minHeight: "100vh", background: "var(--brand-bg)", paddingTop: "7rem", paddingBottom: "5rem" }}>
            <Seo
                title="Калкулатор за приемен бал — правила на университетите"
                description={`Изчисли приемния си бал за ${ADMISSION_YEAR_SHORT} г. Условия за прием в каталог с ${UNIVERSITIES} университета и ${SPECIALTIES} специалности. Безплатно, без регистрация.`}
                path="/calculator"
                image="https://uniput.eu/og/calculator.png"
            />
            <JsonLd data={CALCULATOR_SCHEMA} />
            <div style={{ maxWidth: "72rem", margin: "0 auto", padding: "0 1.5rem" }}>

                {/* Header */}
                <m.div initial={{ opacity: 0, y: 20, }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} style={{ marginBottom: "2.5rem" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "0.625rem", marginBottom: "0.75rem" }}>
                        <div style={{ width: "7px", height: "7px", borderRadius: "50%", background: "var(--brand-violet)", boxShadow: "0 0 10px var(--brand-violet)" }} />
                        <span style={{ color: "var(--brand-violet)", fontSize: "12px", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.12em" }}>Калкулатор</span>
                    </div>
                    <h1 style={{ fontSize: "clamp(2rem,5vw,3rem)", fontWeight: 900, color: "var(--brand-text)", lineHeight: 1.1, letterSpacing: "-0.03em", margin: "0 0 0.625rem", textWrap: "balance" }}>
                        Изчисли своя{" "}
                        <span style={{ background: "linear-gradient(135deg,var(--brand-violet),var(--brand-cyan))", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                            приемен бал
                        </span>
                    </h1>

                    {/* Notice */}
                    <div style={{ display: "flex", alignItems: "flex-start", gap: "0.625rem", padding: "0.875rem 1rem", background: "rgba(23,86,217,0.08)", border: "1px solid rgba(23,86,217,0.2)", borderRadius: "0.875rem", maxWidth: "36rem" }}>
                        <AlertCircle size={15} style={{ color: "var(--brand-violet)", flexShrink: 0, marginTop: "1px" }} />
                        <p style={{ fontSize: "13px", color: "var(--brand-muted)", margin: 0, lineHeight: 1.5 }}>
                            Калкулаторът има формулите на 51 университета. Ако не намираш своята специалност, пиши ни на uniput1000@gmail.com — ще я добавим.
                        </p>
                    </div>
                </m.div>

                {/* Load error banner */}
                <AnimatePresence>
                    {loadError && (
                        <m.div
                            initial={{ opacity: 0, y: -8 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -8 }}
                            style={{
                                display: "flex",
                                alignItems: "flex-start",
                                gap: "0.75rem",
                                padding: "1rem 1.125rem",
                                background: "rgba(248,113,113,0.08)",
                                border: "1px solid rgba(248,113,113,0.25)",
                                borderRadius: "0.875rem",
                                marginBottom: "1rem",
                            }}
                        >
                            <AlertCircle size={16} style={{ color: "#f87171", flexShrink: 0, marginTop: "2px" }} />
                            <div style={{ flex: 1 }}>
                                <p style={{ fontSize: "13px", color: "var(--brand-text)", margin: 0, lineHeight: 1.5, fontWeight: 600 }}>
                                    {loadError}
                                </p>
                            </div>
                            <button
                                type="button"
                                onClick={() => window.location.reload()}
                                style={{
                                    padding: "0.4rem 0.875rem",
                                    background: "rgba(248,113,113,0.15)",
                                    border: "1px solid rgba(248,113,113,0.35)",
                                    borderRadius: "0.5rem",
                                    color: "#f87171",
                                    fontWeight: 700,
                                    fontSize: "12px",
                                    cursor: "pointer",
                                    fontFamily: "inherit",
                                    flexShrink: 0,
                                }}
                            >
                                Опитай пак
                            </button>
                        </m.div>
                    )}
                </AnimatePresence>

                {/* Selectors */}
                <m.div
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.1 }}
                    style={{ background: S.surface, backdropFilter: "blur(12px)", border: `1px solid ${S.border}`, borderRadius: "1.25rem", padding: "1.25rem", marginBottom: "1.5rem" }}
                >
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}>
                        {/* Faculty searchable */}
                        <div style={{ position: "relative" }}>
                            <div style={{ position: "relative" }}>
                                <input
                                    type="text"
                                    placeholder="Търси факултет..."
                                    value={facultySearch}
                                    onChange={e => { setFacultySearch(e.target.value); setDropdownShowAll(false); setIsFacultyDropdownOpen(true); }}
                                    onClick={() => { setIsFacultyDropdownOpen(true); setDropdownShowAll(true); }}
                                    onFocus={e => { setIsFacultyDropdownOpen(true); setDropdownShowAll(true); e.target.style.borderColor = "rgba(23,86,217,0.5)"; }}
                                    onBlur={e => { e.target.style.borderColor = "rgba(148,163,184,0.12)"; }}
                                    style={{ ...S.input, paddingLeft: "1rem", paddingRight: "4.5rem" }}
                                />
                                <div style={{ position: "absolute", right: "0.75rem", top: "50%", transform: "translateY(-50%)", display: "flex", alignItems: "center", gap: "0.375rem" }}>
                                    {facultySearch && (
                                        <button type="button" onClick={clearFaculty} style={{ background: "none", border: "none", cursor: "pointer", padding: "2px", color: "var(--brand-muted)", display: "flex" }}>
                                            <XCircle size={15} />
                                        </button>
                                    )}
                                    <ChevronDown size={16} style={{ color: "var(--brand-muted)", transition: "transform 0.2s", transform: isFacultyDropdownOpen ? "rotate(180deg)" : "none" }} />
                                </div>
                            </div>

                            <AnimatePresence>
                                {isFacultyDropdownOpen && (
                                    <>
                                        <div style={{ position: "fixed", inset: 0, zIndex: 10 }} onClick={() => { setIsFacultyDropdownOpen(false); setDropdownShowAll(false); }} />
                                        <m.div
                                            initial={{ opacity: 0, y: -6 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            exit={{ opacity: 0, y: -6 }}
                                            transition={{ duration: 0.15 }}
                                            style={{ position: "absolute", top: "calc(100% + 6px)", left: 0, right: 0, background: "var(--brand-dropdown-bg)", border: "1px solid var(--brand-border)", borderRadius: "0.875rem", maxHeight: "14rem", overflowY: "auto", zIndex: 20, boxShadow: "0 20px 60px var(--brand-shadow)" }}
                                        >
                                            {filteredFaculties.length > 0 ? filteredFaculties.map((f, i) => (
                                                <button
                                                    key={i}
                                                    type="button"
                                                    onClick={() => { setSelectedFaculty(f); setFacultySearch(f); setSelectedSpecialtyName(""); setSelectedCity(""); setSelectedUniversity(""); setIsFacultyDropdownOpen(false); setDropdownShowAll(false); }}
                                                    style={{ width: "100%", textAlign: "left", padding: "0.625rem 1rem", fontSize: "13px", fontWeight: 500, color: "var(--brand-text)", background: "none", border: "none", borderBottom: i < filteredFaculties.length - 1 ? "1px solid rgba(148,163,184,0.08)" : "none", cursor: "pointer", fontFamily: "inherit", transition: "background 0.15s" }}
                                                    onMouseEnter={e => (e.currentTarget.style.background = "rgba(23,86,217,0.08)")}
                                                    onMouseLeave={e => (e.currentTarget.style.background = "none")}
                                                >
                                                    {f}
                                                </button>
                                            )) : (
                                                <div style={{ padding: "1rem", textAlign: "center", color: "var(--brand-muted)", fontSize: "13px" }}>Няма резултати</div>
                                            )}
                                        </m.div>
                                    </>
                                )}
                            </AnimatePresence>
                        </div>

                        {/* Specialty */}
                        <select
                            value={selectedSpecialtyName}
                            onChange={e => setSelectedSpecialtyName(e.target.value)}
                            disabled={!selectedFaculty}
                            aria-label="Избери специалност"
                            style={{ ...S.input, cursor: selectedFaculty ? "pointer" : "not-allowed", opacity: selectedFaculty ? 1 : 0.5 }}
                        >
                            <option value="" style={{ background: "var(--brand-dropdown-bg)" }}>Избери специалност</option>
                            {availableSpecialties.map((s, i) => <option key={i} value={s} style={{ background: "var(--brand-dropdown-bg)" }}>{s}</option>)}
                        </select>
                    </div>

                    {/* Optional filters */}
                    <AnimatePresence>
                        {selectedFaculty && (
                            <m.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: "auto" }}
                                exit={{ opacity: 0, height: 0 }}
                                style={{ overflow: "hidden", marginTop: "0.75rem", paddingTop: "0.75rem", borderTop: "1px solid rgba(148,163,184,0.08)", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}
                            >
                                <select
                                    value={selectedCity}
                                    onChange={e => { setSelectedCity(e.target.value); if (selectedSpecialtyName && !filteredData.find(d => d.specialty === selectedSpecialtyName && (!e.target.value || d.city === e.target.value))) setSelectedSpecialtyName(""); }}
                                    style={{ ...S.input, height: "2.5rem", fontSize: "13px", cursor: "pointer" }}
                                >
                                    <option value="" style={{ background: "var(--brand-dropdown-bg)" }}>Всички градове</option>
                                    {cities.map((c, i) => <option key={i} value={c} style={{ background: "var(--brand-dropdown-bg)" }}>{c}</option>)}
                                </select>
                                <select
                                    value={selectedUniversity}
                                    onChange={e => { setSelectedUniversity(e.target.value); if (selectedSpecialtyName && !filteredData.find(d => d.specialty === selectedSpecialtyName && (!e.target.value || d.university_name === e.target.value))) setSelectedSpecialtyName(""); }}
                                    style={{ ...S.input, height: "2.5rem", fontSize: "13px", cursor: "pointer" }}
                                >
                                    <option value="" style={{ background: "var(--brand-dropdown-bg)" }}>Всички университети</option>
                                    {universities.map((u, i) => <option key={i} value={u} style={{ background: "var(--brand-dropdown-bg)" }}>{u}</option>)}
                                </select>
                            </m.div>
                        )}
                    </AnimatePresence>
                </m.div>

                {/* How it works — shown only when no faculty selected AND dropdown is closed */}
                {!selectedFaculty && !isFacultyDropdownOpen && (
                    <m.div
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5, delay: 0.15 }}
                        style={{ marginBottom: "2rem"  }}
                    >
                        <h2 style={{ fontSize: "11px", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.12em", color: "var(--brand-cyan)", marginBottom: "1rem", margin: 0 }}>
                            Как се изчислява баловия резултат
                        </h2>
                        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))", gap: "0.875rem" }}>
                            {HOW_STEPS.map(step => {
                                const Icon = step.icon;
                                return (
                                    <div key={step.num} style={{ background: S.surface, backdropFilter: "blur(12px)", border: `1px solid ${S.border}`, borderRadius: "1.25rem", padding: "1.25rem", display: "flex", flexDirection: "column", gap: "0.75rem" }}>
                                        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                                            <div style={{ padding: "0.5rem", borderRadius: "0.625rem", background: "linear-gradient(135deg,rgba(23,86,217,0.12),rgba(23,86,217,0.12))", display: "inline-flex" }}>
                                                <Icon size={18} style={{ color: "var(--brand-cyan)" }} />
                                            </div>
                                            <span style={{ fontSize: "2rem", fontWeight: 900, color: "var(--brand-border)", letterSpacing: "-0.04em" }}>{step.num}</span>
                                        </div>
                                        <div>
                                            <p style={{ fontSize: "14px", fontWeight: 700, color: "var(--brand-text)", margin: "0 0 0.3rem" }}>{step.title}</p>
                                            <p style={{ fontSize: "12px", color: "var(--brand-muted)", margin: 0, lineHeight: 1.55 }}>{step.desc}</p>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </m.div>
                )}

                {/* ДЗИ Стратег промо — за 11-класници, които още нямат оценки */}
                {!selectedFaculty && !isFacultyDropdownOpen && (
                    <m.div
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5, delay: 0.18 }}
                        style={{ marginBottom: "2rem" }}
                    >
                        <Link
                            to="/dzi-strateg"
                            style={{
                                display: "flex", alignItems: "center", gap: "1rem",
                                padding: "1.25rem 1.5rem",
                                background: "linear-gradient(135deg, rgba(23,86,217,0.08), rgba(23,86,217,0.08))",
                                border: "1px solid var(--brand-card-border)",
                                borderRadius: "1.25rem",
                                textDecoration: "none",
                            }}
                        >
                            <div style={{ flexShrink: 0, padding: "0.625rem", borderRadius: "0.75rem", background: "linear-gradient(135deg,var(--brand-cyan),var(--brand-violet))", display: "inline-flex" }}>
                                <Compass size={20} color="#fff" strokeWidth={1.5} />
                            </div>
                            <div style={{ flex: 1, minWidth: 0 }}>
                                <p style={{ fontSize: "14px", fontWeight: 800, color: "var(--brand-text)", margin: "0 0 0.2rem", letterSpacing: "-0.01em" }}>
                                    Още нямаш оценки? Виж кой втори ДЗИ ти отваря най-много специалности
                                </p>
                                <p style={{ fontSize: "12px", color: "var(--brand-muted)", margin: 0, lineHeight: 1.5 }}>
                                    ДЗИ Стратег — за 11. клас и всеки, който планира матурите си.
                                </p>
                            </div>
                            <ArrowRight size={18} style={{ flexShrink: 0, color: "var(--brand-cyan)" }} />
                        </Link>
                    </m.div>
                )}

                {/* DZI → Grade Converter — shown only when no faculty selected AND dropdown is closed */}
                {!selectedFaculty && !isFacultyDropdownOpen && (
                    <m.div
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5, delay: 0.22 }}
                        style={{ background: S.surface, backdropFilter: "blur(12px)", border: `1px solid ${S.border}`, borderRadius: "1.25rem", padding: "1.5rem", marginBottom: "2rem" }}
                    >
                        {/* Header */}
                        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "1.25rem" }}>
                            <div style={{ padding: "0.375rem", borderRadius: "0.5rem", background: "linear-gradient(135deg,rgba(23,86,217,0.12),rgba(23,86,217,0.12))", display: "inline-flex" }}>
                                <Zap size={15} style={{ color: "var(--brand-cyan)" }} />
                            </div>
                            <h2 style={{ fontSize: "14px", fontWeight: 800, color: "var(--brand-text)", margin: 0 }}>
                                Конвертор: точки от ДЗИ → оценка
                            </h2>
                        </div>

                        {/* Input + Slider */}
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem", alignItems: "center", marginBottom: "1.25rem" }}>
                            <div>
                                <label style={{ fontSize: "11px", fontWeight: 700, color: "var(--brand-muted)", textTransform: "uppercase", letterSpacing: "0.1em", display: "block", marginBottom: "0.4rem" }}>
                                    Точки (0 – 100)
                                </label>
                                <input
                                    type="number"
                                    min="0"
                                    max="100"
                                    step="0.25"
                                    placeholder="напр. 74.5"
                                    value={dziPoints}
                                    onChange={handleDziChange}
                                    style={{
                                        ...S.input,
                                        fontFamily: "monospace",
                                        fontSize: "1.1rem",
                                        fontWeight: 700,
                                        borderColor: dziError ? "rgba(248,113,113,0.6)" : undefined,
                                    }}
                                    onFocus={e => { e.target.style.borderColor = dziError ? "rgba(248,113,113,0.6)" : "rgba(23,86,217,0.5)"; }}
                                    onBlur={e => { e.target.style.borderColor = dziError ? "rgba(248,113,113,0.6)" : "var(--brand-input-border)"; }}
                                />
                                {dziError && (
                                    <p style={{
                                        marginTop: "0.35rem",
                                        fontSize: "11px",
                                        fontWeight: 600,
                                        color: "#fca5a5",
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "0.3rem",
                                    }}>
                                        <AlertCircle size={11} /> {dziError}
                                    </p>
                                )}
                            </div>

                            {/* Live result */}
                            <div style={{
                                padding: "1rem",
                                borderRadius: "0.875rem",
                                background: dziResult ? dziResult.band.bg : "var(--brand-border)",
                                border: `2px solid ${dziResult ? dziResult.band.border : "var(--brand-border)"}`,
                                textAlign: "center",
                                transition: "all 0.3s",
                                minHeight: "3rem",
                                display: "flex",
                                flexDirection: "column",
                                alignItems: "center",
                                justifyContent: "center",
                                gap: "0.2rem",
                                position: "relative",
                            }}>
                                {dziResult ? (
                                    <>
                                        <span style={{ fontSize: "2.25rem", fontWeight: 900, lineHeight: 1, letterSpacing: "-0.04em", color: dziResult.band.color, fontFamily: "monospace" }}>
                                            {dziResult.grade.toFixed(2)}
                                        </span>
                                        <span style={{ fontSize: "11px", fontWeight: 700, color: dziResult.band.color, textTransform: "uppercase", letterSpacing: "0.08em" }}>
                                            {dziResult.band.label}
                                        </span>
                                        <button
                                            type="button"
                                            onClick={copyGrade}
                                            title="Копирай оценката"
                                            style={{
                                                position: "absolute", top: "0.5rem", right: "0.5rem",
                                                background: "none", border: "none", cursor: "pointer",
                                                color: dziResult.band.color, opacity: 0.6, padding: "2px",
                                                display: "flex", alignItems: "center",
                                            }}
                                        >
                                            {copied ? <Check size={13} /> : <Copy size={13} />}
                                        </button>
                                    </>
                                ) : (
                                    <span style={{ fontSize: "13px", color: "var(--brand-muted)", fontWeight: 600 }}>
                                        Въведи точки
                                    </span>
                                )}
                            </div>
                        </div>

                        {/* Slider */}
                       

                        {/* Reference table */}
                        <div style={{ borderTop: "1px solid var(--brand-border)", paddingTop: "1rem" }}>
                            <p style={{ fontSize: "11px", fontWeight: 700, color: "var(--brand-muted)", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: "0.625rem" }}>
                                Скала за оценяване
                            </p>
                            <div style={{ display: "flex", flexDirection: "column", gap: "0.3rem" }}>
                                {DZI_BANDS.map(b => {
                                    const isActive = dziResult?.band.label === b.label;
                                    return (
                                        <div
                                            key={b.label}
                                            style={{
                                                display: "grid",
                                                gridTemplateColumns: "1fr 2fr 1fr",
                                                alignItems: "center",
                                                gap: "0.75rem",
                                                padding: "0.4rem 0.75rem",
                                                borderRadius: "0.5rem",
                                                background: isActive ? b.bg : "transparent",
                                                border: `1px solid ${isActive ? b.border : "transparent"}`,
                                                transition: "all 0.25s",
                                            }}
                                        >
                                            <span style={{ fontSize: "12px", fontWeight: 700, color: b.color }}>
                                                {b.label}
                                            </span>
                                            <div style={{ height: "6px", borderRadius: "999px", background: "var(--brand-border)", overflow: "hidden" }}>
                                                <div style={{
                                                    height: "100%",
                                                    borderRadius: "999px",
                                                    background: b.color,
                                                    width: `${b.max}%`,
                                                    opacity: isActive ? 1 : 0.35,
                                                    transition: "opacity 0.25s",
                                                }} />
                                            </div>
                                            <span style={{ fontSize: "11px", color: "var(--brand-muted)", textAlign: "right", fontFamily: "monospace" }}>
                                                {b.min} – {b.max} т.
                                            </span>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </m.div>
                )}

                {/* Formula legend — shown only when no faculty selected AND dropdown is closed */}
                {!selectedFaculty && !isFacultyDropdownOpen && (
                    <m.div
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5, delay: 0.26 }}
                        style={{ background: S.surface, backdropFilter: "blur(12px)", border: `1px solid ${S.border}`, borderRadius: "1.25rem", padding: "1.25rem", marginBottom: "2rem" }}
                    >
                        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.875rem" }}>
                            <div style={{ padding: "0.375rem", borderRadius: "0.5rem", background: "linear-gradient(135deg,rgba(23,86,217,0.12),rgba(23,86,217,0.12))", display: "inline-flex" }}>
                                <Info size={15} style={{ color: "var(--brand-violet)" }} />
                            </div>
                            <p style={{ fontSize: "13px", fontWeight: 700, color: "var(--brand-text)", margin: 0 }}>Легенда на формулите</p>
                        </div>
                        <div style={{ display: "flex", flexDirection: "column", gap: "0.3rem" }}>
                            {FORMULA_LEGEND.map(({ symbol, desc }) => (
                                <div key={symbol} style={{ display: "grid", gridTemplateColumns: "7.5rem 1fr", gap: "0.75rem", alignItems: "baseline", padding: "0.375rem 0.5rem", borderRadius: "0.5rem" }}>
                                    <code style={{ fontSize: "12px", fontWeight: 700, color: "var(--brand-cyan)", fontFamily: "monospace", whiteSpace: "nowrap" }}>{symbol}</code>
                                    <span style={{ fontSize: "12px", color: "var(--brand-muted)", lineHeight: 1.5 }}>{desc}</span>
                                </div>
                            ))}
                        </div>
                    </m.div>
                )}

                {/* Tips — shown only when no faculty selected AND dropdown is closed */}
                {!selectedFaculty && !isFacultyDropdownOpen && (
                    <m.div
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5, delay: 0.29 }}
                        style={{ background: S.surface, backdropFilter: "blur(12px)", border: `1px solid ${S.border}`, borderRadius: "1.25rem", padding: "1.25rem", marginBottom: "2rem" }}
                    >
                        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.875rem" }}>
                            <Lightbulb size={15} style={{ color: "#FBBF24" }} />
                            <p style={{ fontSize: "13px", fontWeight: 700, color: "var(--brand-text)", margin: 0 }}>Съвети за по-добър резултат</p>
                        </div>
                        <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: "0.5rem" }}>
                            {TIPS.map((tip, i) => (
                                <li key={i} style={{ display: "flex", alignItems: "flex-start", gap: "0.5rem" }}>
                                    <ArrowRight size={13} style={{ color: "var(--brand-cyan)", flexShrink: 0, marginTop: "2px" }} />
                                    <span style={{ fontSize: "13px", color: "var(--brand-muted)", lineHeight: 1.55 }}>{tip}</span>
                                </li>
                            ))}
                        </ul>
                    </m.div>
                )}

                {plovdivRows.map(({ row, program }) => <div key={row.id}><PlovdivCalculator row={row} program={program} /><AdmissionSourceNote row={row} /></div>)}
                {vfuRows.map(({ row, program }) => <div key={row.id}><VfuCalculator row={row} program={program} /><AdmissionSourceNote row={row} /></div>)}
                {uardRows.map(({ row, program }) => <div key={row.id}><UardCalculator row={row} program={program} /><AdmissionSourceNote row={row} /></div>)}
                {tourismCollegeRows.map(({ row, program }) => <div key={row.id}><TourismCollegeCalculator row={row} program={program} /><AdmissionSourceNote row={row} /></div>)}
                {nmaRows.map(({ row, program }) => <div key={row.id}><NmaCalculator row={row} program={program} /><AdmissionSourceNote row={row} /></div>)}
                {nbuRows.map(({ row, program }) => <div key={row.id}><NbuCalculator row={row} program={program} /><AdmissionSourceNote row={row} /></div>)}
                {unavailableRows.map(row => (
                    <section key={row.id} className="mb-4 rounded-2xl border p-5">
                        <h3>{row.university_name} · {row.specialty}</h3>
                        <p>{row.university_name === "Американски университет в България – Благоевград"
                            ? "Приемът в АУБ разглежда успеха от училище, владеенето на английски, есе, препоръка, постижения и интервю. SAT/ACT е по желание. Университетът не публикува единна числова формула за тези програми."
                            : row.university_name === "Висше училище по мениджмънт – Варна"
                            ? "Приемът във ВУМ включва преглед на документи и интервю, а при липса на признат езиков сертификат — онлайн изпит по английски. Не е публикуван един числов максимален бал за тази програма."
                            : "Автоматичен бал за тази програма не е наличен. Провери условията за прием в правилника на университета."}</p>
                        <AdmissionSourceNote row={row} />
                    </section>
                ))}
                {/* Grade inputs */}
                <AnimatePresence>
                    {selectedSpecialtyName && rowsForSelectedSpecialty.length > 0 && (
                        <m.div
                            initial={{ opacity: 0, y: 16 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.4 }}
                            style={{ background: S.surface, backdropFilter: "blur(12px)", border: `1px solid ${S.border}`, borderRadius: "1.25rem", padding: "1.5rem", marginBottom: "1.5rem" }}
                        >
                            <GradeInputSection
                                coefficients={coefficientsForInputs}
                                separateKeys={separateDiplomaKeys}
                                faculty={selectedFaculty}
                                specialty={selectedSpecialtyName}
                                onGradesChange={setGrades}
                            />
                        </m.div>
                    )}
                </AnimatePresence>

                {/* Endowed progress: показва се от ПЪРВИЯ резултат нататък (никога 0/3) —
                    честен брояч, не наказание. CLAUDE.md §17: loss aversion честна версия. */}
                {!user && unlockedSpecialtyKeys.size > 0 && (
                    <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.875rem", fontSize: "12px", color: "var(--brand-muted)" }}>
                        <Bookmark size={13} style={{ color: "var(--brand-cyan)", flexShrink: 0 }} strokeWidth={1.5} />
                        Без акаунт: <strong style={{ color: "var(--brand-text)", fontFamily: "monospace" }}>{Math.min(unlockedSpecialtyKeys.size, GATE_LIMIT)}/{GATE_LIMIT}</strong> специалности запазени на този браузър
                    </div>
                )}

                {/* Gate A — заключена специалност (виж isSpecialtyLocked по-горе).
                    Реален wall, не blur: НЕ пресмятаме/показваме бал тук — стойността
                    отвъд GATE_LIMIT наистина е зад акаунта, не примамка. */}
                {isSpecialtyLocked && (
                    <m.div
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                        style={{
                            background: "linear-gradient(135deg, rgba(23,86,217,0.08), rgba(23,86,217,0.08))",
                            border: "1px solid var(--brand-card-border)",
                            borderRadius: "1.25rem",
                            padding: "2rem 1.75rem",
                            textAlign: "center",
                        }}
                    >
                        <div style={{
                            width: 52, height: 52, borderRadius: "1rem", margin: "0 auto 1.25rem",
                            background: "linear-gradient(135deg, var(--brand-cyan), var(--brand-violet))",
                            display: "flex", alignItems: "center", justifyContent: "center",
                            boxShadow: "0 12px 30px rgba(23,86,217,0.3)",
                        }}>
                            <Lock size={24} color="#fff" strokeWidth={2} />
                        </div>
                        <h3 style={{ margin: 0, fontSize: "1.25rem", fontWeight: 800, color: "var(--brand-text)", letterSpacing: "-0.01em", textWrap: "balance" }}>
                            Сравни вече {unlockedHistory.length} специалности
                        </h3>
                        <p style={{ margin: "0.625rem auto 0", fontSize: "0.9375rem", color: "var(--brand-muted)", lineHeight: 1.6, maxWidth: "42ch" }}>
                            {unlockedHistory.map(h => h.specialty).join(" · ")} — балът им се пази само на този браузър.
                            Направи безплатен акаунт, за да ги запазиш и да продължиш без ограничение.
                        </p>
                        <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "0.625rem", marginTop: "1.5rem" }}>
                            <button
                                type="button"
                                onClick={handleGateGoogleSignup}
                                style={{
                                    display: "inline-flex", alignItems: "center", gap: "0.625rem",
                                    height: "3rem", padding: "0 1.5rem",
                                    background: "var(--brand-surface)", border: "1px solid var(--brand-input-border)",
                                    borderRadius: "0.75rem", color: "var(--brand-text)", fontSize: "14px",
                                    fontWeight: 700, cursor: "pointer", fontFamily: "inherit",
                                }}
                            >
                                <svg width="18" height="18" viewBox="0 0 24 24">
                                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05" />
                                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.66l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                                </svg>
                                Продължи с Google
                            </button>
                            <Link
                                to="/register"
                                state={{ from: { pathname: location.pathname, search: location.search } }}
                                style={{
                                    display: "inline-flex", alignItems: "center",
                                    height: "3rem", padding: "0 1.25rem",
                                    background: "transparent", border: "1px solid var(--brand-border)",
                                    borderRadius: "0.75rem", color: "var(--brand-text)", fontSize: "14px",
                                    fontWeight: 600, textDecoration: "none",
                                }}
                            >
                                С имейл
                            </Link>
                        </div>
                        {/* Равнопоставен изход — никога по-малък/по-сив от CTA-то (DSA чл. 25,
                            без confirmshaming): регистрацията е избор, не капан. */}
                        <div style={{ marginTop: "1.25rem" }}>
                            <Link
                                to="/universities/"
                                style={{ fontSize: "13px", fontWeight: 600, color: "var(--brand-cyan)", textDecoration: "none" }}
                            >
                                Не сега — към университетите
                            </Link>
                        </div>
                    </m.div>
                )}

                {/* Results */}
                {calcResults.length > 0 && !isSpecialtyLocked && (
                    <m.div
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: 0.1 }}
                        style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(320px,1fr))", gap: "1rem" }}
                    >
                        {calcResults.map(({ item, score, maxBall, formatted, minScore, isAbove, marginPts, chance, percentOfMax, hasStarted, hasMissing, missingSlots }) => (
                                <div key={item.id} style={{ background: S.surface, backdropFilter: "blur(12px)", border: `1px solid ${S.border}`, borderRadius: "1.25rem", padding: "1.5rem", display: "flex", flexDirection: "column", gap: "1rem" }}>

                                    {/* Top: name + score */}
                                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "1rem" }}>
                                        <div style={{ flex: 1, minWidth: 0 }}>
                                            <div style={{ fontSize: "11px", color: "var(--brand-muted)", marginBottom: "0.25rem", fontWeight: 600 }}>{item.university_name}</div>
                                            <h3 style={{ fontSize: "15px", fontWeight: 700, color: "var(--brand-text)", lineHeight: 1.4, margin: 0 }}>{item.specialty}</h3>
                                        </div>
                                        <div style={{ textAlign: "right", flexShrink: 0 }}>
                                            <div style={{ fontSize: "2.5rem", fontWeight: 900, lineHeight: 1, letterSpacing: "-0.04em", color: hasMissing ? "var(--brand-muted)" : isAbove === true && hasStarted ? "#10b981" : "var(--brand-cyan)" }}>
                                                {hasMissing && hasStarted ? "—" : !hasStarted ? "—" : formatted}
                                            </div>
                                            <div style={{ fontSize: "10px", fontWeight: 700, color: "var(--brand-muted)", textTransform: "uppercase", letterSpacing: "0.1em" }}>бал</div>
                                        </div>
                                    </div>

                                    {/* Trust warning — преди да зарадваме ученика с „влизаш", го предупреждаваме за акредитацията */}
                                    {item.accreditation_status && (
                                        <AccreditationWarning status={item.accreditation_status} />
                                    )}

                                    {/* Formula */}
                                    <div style={{ display: "flex", gap: "0.5rem", padding: "0.75rem", background: "rgba(23,86,217,0.06)", border: "1px solid rgba(23,86,217,0.15)", borderRadius: "0.75rem", minWidth: 0 }}>
                                        <Info size={14} style={{ color: "var(--brand-violet)", flexShrink: 0, marginTop: "1px" }} />
                                        <p style={{ fontSize: "12px", color: "var(--brand-muted)", margin: 0, lineHeight: 1.5, wordBreak: "break-word", overflowWrap: "anywhere", minWidth: 0 }}>
                                            <strong style={{ color: "var(--brand-text)" }}>Формула:</strong> {item.formula_description}
                                        </p>
                                    </div>

                                    {(() => {
                                        const source = admissionSource(item);
                                        if (!source) return null;
                                        const verifiedDate = source.verifiedAt
                                            ? new Intl.DateTimeFormat("bg-BG", { dateStyle: "medium" }).format(new Date(source.verifiedAt))
                                            : null;
                                        return (
                                            <div style={{ display: "flex", alignItems: "flex-start", gap: "0.5rem", fontSize: "11px", color: "var(--brand-muted)" }}>
                                                <ExternalLink size={13} style={{ flexShrink: 0, marginTop: "2px", color: "var(--brand-cyan)" }} />
                                                <div>
                                                    <a href={source.url} target="_blank" rel="noopener noreferrer" style={{ color: "var(--brand-cyan)", fontWeight: 700, textDecoration: "underline", textUnderlineOffset: "3px" }}>
                                                        {source.label}
                                                    </a>
                                                    <div style={{ marginTop: "0.2rem" }}>
                                                        {verifiedDate ? `Формулата е сверена на ${verifiedDate}.` : "Официален източник е наличен; формулата очаква ръчна проверка."}
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })()}

                                    {/* Status */}
                                    <div style={{ paddingTop: "0.75rem", borderTop: "1px solid rgba(148,163,184,0.08)", display: "flex", flexDirection: "column", gap: "0.5rem" }}>
                                        {minScore && (
                                            <div style={{ fontSize: "12px", color: "var(--brand-muted)" }}>
                                                Минимален бал {minScore.year}{minScore.round ? ` (${minScore.round}-${minScore.round === 1 ? "во" : minScore.round === 2 ? "ро" : "то"} класиране)` : " (финално класиране)"}:{" "}
                                                <strong style={{ color: "var(--brand-text)", fontFamily: "monospace" }}>
                                                    {minScore.minBall.toFixed(2)}{minScore.minBallMax > minScore.minBall ? `–${minScore.minBallMax.toFixed(2)}` : ""}
                                                </strong>
                                                {" "}· официални данни от КСК {minScore.year}
                                            </div>
                                        )}

                                        {hasMissing && hasStarted && (
                                            <div style={{ display: "flex", alignItems: "center", gap: "0.375rem", fontSize: "12px", color: "#f87171", fontWeight: 600 }}>
                                                <AlertCircle size={13} />
                                                Липсват: {missingSlots.map(describeMissingTerm).join(", ")}
                                            </div>
                                        )}

                                        {!hasMissing && hasStarted && minScore && chance && (
                                            <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem", padding: "0.75rem", borderRadius: "0.75rem", background: CHANCE_TONES[chance.tone].bg, border: `1px solid ${CHANCE_TONES[chance.tone].border}` }}>
                                                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "0.5rem" }}>
                                                    <div style={{ display: "flex", alignItems: "center", gap: "0.375rem", fontSize: "12px", fontWeight: 700, color: "var(--brand-muted)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
                                                        <Compass size={13} strokeWidth={1.5} />
                                                        Шанс за прием
                                                    </div>
                                                    <span style={{ padding: "0.2rem 0.625rem", borderRadius: "999px", fontSize: "11px", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", background: CHANCE_TONES[chance.tone].bg, color: CHANCE_TONES[chance.tone].text, border: `1px solid ${CHANCE_TONES[chance.tone].border}` }}>
                                                        {chance.label}
                                                    </span>
                                                </div>
                                                <div style={{ display: "flex", alignItems: "center", gap: "0.375rem", fontSize: "12px", fontWeight: 700, color: CHANCE_TONES[chance.tone].text }}>
                                                    {marginPts >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                                                    {marginPts >= 0 ? "+" : "−"}{Math.abs(marginPts).toFixed(2)} т. спрямо миналогодишния праг
                                                </div>
                                                <p style={{ margin: 0, fontSize: "11px", color: "var(--brand-muted)", lineHeight: 1.5 }}>
                                                    {chance.blurb}
                                                </p>
                                                <p style={{ margin: 0, display: "flex", alignItems: "flex-start", gap: "0.375rem", fontSize: "11px", color: "var(--brand-muted)", lineHeight: 1.5 }}>
                                                    <AlertCircle size={12} style={{ flexShrink: 0, marginTop: "2px" }} />
                                                    Ориентир по данни от {minScore.year} г., не гаранция. Прагът се мени всяка година според броя кандидати.
                                                </p>
                                            </div>
                                        )}

                                        {!hasMissing && hasStarted && !minScore && percentOfMax !== null && (
                                            <>
                                                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                                                    <div style={{ fontSize: "12px", fontWeight: 700, color: "var(--brand-text)" }}>
                                                        Твоят бал е <span style={{ fontFamily: "monospace" }}>{percentOfMax.toFixed(0)}%</span> от максималния
                                                    </div>
                                                    <span style={{ padding: "0.2rem 0.625rem", borderRadius: "999px", fontSize: "11px", fontWeight: 700, textTransform: "uppercase", background: "rgba(251,191,36,0.1)", color: "#FBBF24", border: "1px solid rgba(251,191,36,0.25)" }}>
                                                        {percentOfMax.toFixed(0)}% ОТ МАКС.
                                                    </span>
                                                </div>
                                                <div style={{ display: "flex", alignItems: "flex-start", gap: "0.375rem", fontSize: "11px", color: "var(--brand-muted)", lineHeight: 1.5 }}>
                                                    <AlertCircle size={12} style={{ flexShrink: 0, marginTop: "2px" }} />
                                                    {item.university_name} не публикува минимални балове за прием, затова не можем да кажем дали влизаш.
                                                </div>
                                            </>
                                        )}

                                        {hasStarted && !hasMissing && cohortStats[item.id]?.score === Number(formatted) && (
                                            <div style={{ display: "flex", flexDirection: "column", gap: "0.25rem" }}>
                                                <div style={{ display: "flex", alignItems: "center", gap: "0.375rem", fontSize: "12px", fontWeight: 700, color: "var(--brand-text)" }}>
                                                    <Users size={13} strokeWidth={1.5} style={{ color: "var(--brand-violet)", flexShrink: 0 }} />
                                                    <span>Балът ти е по-висок от <span style={{ fontFamily: "monospace" }}>{cohortStats[item.id].pctBelow}%</span> от изчисленията в УниПът</span>
                                                </div>
                                                <p style={{ margin: 0, fontSize: "11px", color: "var(--brand-muted)", lineHeight: 1.5 }}>
                                                    Сред {cohortStats[item.id].n} анонимни изчисления за тази програма. Включва и пробни оценки — не е прогноза за прием.{" "}
                                                    <Link to="/privacy#anonimna-statistika" style={{ color: "var(--brand-cyan)" }}>Как работи</Link>
                                                </p>
                                            </div>
                                        )}

                                        {hasStarted && !hasMissing && (
                                            <DeadlineReminder universityName={item.university_name} />
                                        )}

                                        {hasStarted && !hasMissing && (
                                            <div style={{ display: "flex", gap: "0.5rem" }}>
                                                <button
                                                    type="button"
                                                    onClick={() => shareResult({ item, score, chance })}
                                                    style={{
                                                        flex: 1, display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "0.375rem",
                                                        minHeight: "44px", padding: "0 0.75rem",
                                                        borderRadius: "0.625rem", border: "none", cursor: "pointer",
                                                        fontSize: "13px", fontWeight: 700, color: "#fff",
                                                        background: "linear-gradient(135deg, var(--brand-cyan), var(--brand-violet))",
                                                    }}
                                                >
                                                    {shareFeedback?.id === item.id && shareFeedback.kind === "link"
                                                        ? <><Check size={14} /> Копирано</>
                                                        : <><Share2 size={14} strokeWidth={2} /> Сподели</>}
                                                </button>
                                                <button
                                                    type="button"
                                                    onClick={() => saveResultImage({ item, score, maxBall, chance, marginPts, minScore })}
                                                    title="Запази като картинка"
                                                    style={{
                                                        display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "0.375rem",
                                                        minHeight: "44px", padding: "0 0.875rem",
                                                        borderRadius: "0.625rem", border: "1px solid var(--brand-border)", cursor: "pointer",
                                                        fontSize: "13px", fontWeight: 600, color: "var(--brand-text)",
                                                        background: "var(--brand-surface-2)",
                                                    }}
                                                >
                                                    {shareFeedback?.id === item.id && shareFeedback.kind === "image"
                                                        ? <Check size={14} />
                                                        : <Download size={14} strokeWidth={2} />}
                                                    Картинка
                                                </button>
                                            </div>
                                        )}

                                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "0.5rem" }}>
                                            {item.website_url ? (
                                                <a
                                                    href={item.website_url}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    style={{
                                                        display: "inline-flex", alignItems: "center", gap: "0.375rem",
                                                        minHeight: "44px", padding: "0 0.875rem",
                                                        border: "1px solid var(--brand-border)",
                                                        borderRadius: "0.625rem",
                                                        fontSize: "13px", fontWeight: 600,
                                                        color: "var(--brand-cyan)",
                                                        textDecoration: "none",
                                                        background: "rgba(23,86,217,0.06)",
                                                        transition: "background 0.15s, border-color 0.15s",
                                                        flexShrink: 0,
                                                    }}
                                                    onMouseEnter={e => { e.currentTarget.style.background = "rgba(23,86,217,0.14)"; e.currentTarget.style.borderColor = "var(--brand-cyan)"; }}
                                                    onMouseLeave={e => { e.currentTarget.style.background = "rgba(23,86,217,0.06)"; e.currentTarget.style.borderColor = "var(--brand-border)"; }}
                                                >
                                                    <ExternalLink size={13} strokeWidth={2} />
                                                    Провери в сайта
                                                </a>
                                            ) : <span />}
                                            <ReportButton universityName={item.university_name} specialty={item.specialty} />
                                        </div>
                                    </div>
                                </div>
                        ))}
                    </m.div>
                )}

                {/* ── Signup prompt (само за анонимни, след завършен резултат) ──
                    CLAUDE.md §3: "Secondary CTA (Регистрирай се): after the user
                    has seen value — never as the first ask." Тук сме точно в момента
                    на стойност — потребителят току-що видя своя бал.
                    !isSpecialtyLocked — не дублирай с твърдия gate по-горе. */}
                {!user && !signupCardDismissed && !isSpecialtyLocked && calcResults.some(r => r.hasStarted && !r.hasMissing) && (
                    <m.div
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
                        style={{
                            marginTop: "1.5rem",
                            position: "relative",
                            background: "linear-gradient(135deg, rgba(23,86,217,0.08), rgba(23,86,217,0.08))",
                            border: "1px solid var(--brand-card-border)",
                            borderRadius: "1.25rem",
                            padding: "1.5rem 1.75rem",
                            overflow: "hidden",
                        }}
                    >
                        {/* Subtle gradient glow accent */}
                        <div aria-hidden style={{
                            position: "absolute", top: 0, right: 0, width: "240px", height: "100%",
                            background: "radial-gradient(ellipse at right, rgba(23,86,217,0.12), transparent 70%)",
                            pointerEvents: "none",
                        }} />

                        {/* Dismiss бутон */}
                        <button
                            type="button"
                            onClick={dismissSignupCard}
                            aria-label="Скрий"
                            title="Не сега"
                            style={{
                                position: "absolute", top: "0.75rem", right: "0.75rem",
                                background: "transparent", border: "none", cursor: "pointer",
                                padding: "0.375rem", borderRadius: "0.5rem",
                                color: "var(--brand-muted)",
                                display: "flex", alignItems: "center", justifyContent: "center",
                                transition: "opacity 0.15s, background 0.15s",
                            }}
                            onMouseEnter={(e) => { e.currentTarget.style.opacity = "1"; e.currentTarget.style.background = "var(--brand-surface-2)"; }}
                            onMouseLeave={(e) => { e.currentTarget.style.opacity = "0.6"; e.currentTarget.style.background = "transparent"; }}
                        >
                            <XIcon size={14} />
                        </button>

                        <div style={{ display: "flex", alignItems: "flex-start", gap: "1rem", position: "relative" }}>
                            {/* Иконка */}
                            <div style={{
                                flexShrink: 0,
                                width: "44px", height: "44px", borderRadius: "0.75rem",
                                background: "linear-gradient(135deg, var(--brand-cyan), var(--brand-violet))",
                                display: "flex", alignItems: "center", justifyContent: "center",
                                boxShadow: "0 8px 24px rgba(23,86,217,0.25)",
                            }}>
                                <Bookmark size={20} color="#fff" strokeWidth={2} fill="#fff" />
                            </div>

                            {/* Текст + CTA */}
                            <div style={{ flex: 1, minWidth: 0, paddingRight: "1.5rem" }}>
                                <h3 style={{
                                    margin: 0, fontSize: "1.0625rem", fontWeight: 800,
                                    color: "var(--brand-text)", letterSpacing: "-0.01em",
                                }}>
                                    Запази резултата си
                                </h3>
                                <p style={{
                                    margin: "0.375rem 0 1rem", fontSize: "0.875rem",
                                    color: "var(--brand-muted)", lineHeight: 1.55, maxWidth: "44ch",
                                }}>
                                    Регистрирай се за 30 секунди и резултатите ти ще те чакат при следващото посещение. Безплатно, без спам.
                                </p>

                                <div style={{ display: "flex", flexWrap: "wrap", gap: "0.625rem" }}>
                                    <Link
                                        to="/register"
                                        style={{
                                            display: "inline-flex", alignItems: "center", gap: "0.5rem",
                                            padding: "0.625rem 1.25rem",
                                            background: "linear-gradient(135deg, var(--brand-cyan), var(--brand-violet))",
                                            color: "#fff", borderRadius: "0.625rem",
                                            fontSize: "0.875rem", fontWeight: 700,
                                            textDecoration: "none",
                                            transition: "transform 0.18s, box-shadow 0.18s",
                                        }}
                                        onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-1px)"; e.currentTarget.style.boxShadow = "0 8px 20px rgba(23,86,217,0.3)"; }}
                                        onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "none"; }}
                                    >
                                        <UserPlus size={14} strokeWidth={2} />
                                        Регистрирай се
                                    </Link>
                                    <Link
                                        to="/login"
                                        style={{
                                            display: "inline-flex", alignItems: "center",
                                            padding: "0.625rem 1.125rem",
                                            background: "transparent",
                                            color: "var(--brand-text)",
                                            border: "1px solid var(--brand-border)",
                                            borderRadius: "0.625rem",
                                            fontSize: "0.875rem", fontWeight: 600,
                                            textDecoration: "none",
                                            transition: "border-color 0.18s, color 0.18s",
                                        }}
                                        onMouseEnter={(e) => { e.currentTarget.style.borderColor = "var(--brand-cyan)"; e.currentTarget.style.color = "var(--brand-cyan)"; }}
                                        onMouseLeave={(e) => { e.currentTarget.style.borderColor = "var(--brand-border)"; e.currentTarget.style.color = "var(--brand-text)"; }}
                                    >
                                        Вече имам акаунт
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </m.div>
                )}
            </div>

            {/* CLAUDE.md: data source trust signal */}
            {calcResults.length > 0 && (
                <p style={{ marginTop: "1.5rem", fontSize: "11px", color: "var(--brand-muted)", textAlign: "center", letterSpacing: "0.04em" }}>
                    {DATA_FRESHNESS_NOTE} Средният бал е изчислен от историческия максимален бал.
                </p>
            )}

            <style>{`
                input[type="text"]::placeholder { color: var(--brand-muted); opacity: 0.85; }
                select option { background: var(--brand-dropdown-bg); color: var(--brand-text); }
            `}</style>
        </div>
    );
}
